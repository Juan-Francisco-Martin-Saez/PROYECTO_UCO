# UCO Sa Pobla 2.0 — Prototipo visual v0.3

Basado en el ZIP aportado por el usuario. Mantiene el logotipo original, las imágenes `img/00.webp` a `img/30.webp` y la API PHP de muestra sin cambios.

## Probar
Abrir esta carpeta en VS Code y usar Live Server sobre `index.html`, o ejecutar `python -m http.server 8000` en esta carpeta y visitar http://localhost:8000.

## Incluye
- Web Components nativos: `uco-header`, `uco-home`, `uco-footer`.
- Slider hero de cuatro escenas, automático cada 6,5 s, flechas y selectores; se detiene al interactuar y respeta `prefers-reduced-motion`.
- Familias ilustrativas, selección visual de 8 productos y bloque corporativo.
- Diseño responsive para escritorio, tableta y móvil.
- Imágenes locales WebP con `object-fit:cover`, zoom interno y posición ajustada para ocultar bordes heredados de las imágenes.

## Limitaciones intencionadas
El listado de productos es solo una muestra visual: no existe catálogo persistido, stock, precios, compra ni autenticación. El botón Área cliente informa de ello. Las categorías se enlazan a la sección de muestra, no a un catálogo funcional.

## Archivos
`index.html`, `css/global.css`, `css/components.css`, `js/app.js`, `js/components/*.js`, `img/*`, `api/index.php`.

## Próxima fase
Definir el modelo SQLite, la API PHP y la entrada/administración de productos. Integración con GESCOM pospuesta.
