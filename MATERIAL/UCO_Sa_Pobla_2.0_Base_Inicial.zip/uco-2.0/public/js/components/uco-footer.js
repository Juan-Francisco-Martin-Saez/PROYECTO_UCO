class UcoFooter extends HTMLElement {
  constructor(){super();this.attachShadow({mode:'open'});}
  connectedCallback(){
    this.shadowRoot.innerHTML=/*html*/`
      <style>:host{display:block;background:hsl(151 45% 17%);color:white;font-family:'DM Sans',sans-serif}*{box-sizing:border-box}footer{padding:4rem clamp(1.5rem,7vw,8rem) 2rem}.superior{display:flex;justify-content:space-between;gap:2rem;flex-wrap:wrap}.logo{font:900 3rem Outfit,sans-serif;letter-spacing:-.08em}.logo span{color:hsl(78 82% 65%)}p{color:hsl(143 20% 75%);line-height:1.7;max-width:25rem}nav{display:flex;flex-wrap:wrap;gap:1.5rem;align-items:start}a{color:white;text-decoration:none;font-size:.9rem}a:hover{text-decoration:underline}.inferior{margin-top:4rem;border-top:1px solid hsl(0 0% 100% / .2);padding-top:1.5rem;font-size:.8rem;color:hsl(143 20% 75%)}</style>
      <footer id="contacto"><div class="superior"><div><div class="logo">UCO<span>.</span></div><p>UCO Sa Pobla. Productos, cercanía y soluciones para profesionales.</p></div><nav aria-label="Enlaces de pie de página"><a href="#inicio">Inicio</a><a href="#catalogo">Productos</a><a href="#nosotros">Nosotros</a><a href="https://ucosapobla.com/es/" target="_blank" rel="noopener noreferrer">Web actual ↗</a></nav></div><div class="inferior">© ${new Date().getFullYear()} UCO Sa Pobla · Prototipo de desarrollo 2.0</div></footer>`;
  }
}
customElements.define('uco-footer',UcoFooter);
