class UcoHeader extends HTMLElement {
  constructor(){super();this.attachShadow({mode:'open'});}
  connectedCallback(){
    this.shadowRoot.innerHTML=/*html*/`
      <style>
        :host{display:block;position:sticky;top:0;z-index:100;font-family:'DM Sans',sans-serif}*{box-sizing:border-box}
        header{height:5.3rem;padding:0 clamp(1.2rem,5vw,6rem);display:flex;align-items:center;justify-content:space-between;gap:2rem;background:hsl(42 48% 96% / .96);backdrop-filter:blur(1rem);border-bottom:1px solid hsl(151 20% 80%)}
        .logo{font-family:Outfit,sans-serif;font-size:2rem;font-weight:900;letter-spacing:-.09em;color:hsl(151 45% 17%);text-decoration:none}.logo span{color:hsl(93 65% 40%)}
        nav{display:flex;align-items:center;gap:clamp(1rem,2.5vw,2.5rem)}nav a{font-size:.9rem;font-weight:700;text-decoration:none;color:hsl(155 24% 17%);transition:color .2s}nav a:hover{color:hsl(93 65% 40%)}
        .cliente{background:hsl(151 45% 17%);color:white;border:0;border-radius:3rem;padding:.9rem 1.5rem;font-weight:700}.menu{display:none;border:0;background:none;font-size:1.8rem;color:hsl(151 45% 17%)}
        @media(max-width:55rem){.menu{display:block}nav{display:none;position:absolute;top:100%;left:0;right:0;background:hsl(42 48% 96%);padding:2rem;flex-direction:column;align-items:stretch;box-shadow:0 1rem 2rem hsl(151 45% 17% / .12)}nav.abierto{display:flex}}
      </style>
      <header>
        <a class="logo" href="#inicio" aria-label="UCO Sa Pobla">UCO<span>.</span></a>
        <button class="menu" aria-label="Abrir menú" aria-expanded="false" aria-controls="navegacion">☰</button>
        <nav id="navegacion">
          <a href="#inicio">Inicio</a><a href="#catalogo">Productos</a><a href="#nosotros">Nosotros</a><a href="#contacto">Contacto</a>
          <button class="cliente" type="button">Área de clientes ↗</button>
        </nav>
      </header>`;
    const menu=this.shadowRoot.querySelector('.menu'),nav=this.shadowRoot.querySelector('nav');
    menu.addEventListener('click',()=>{const abierto=nav.classList.toggle('abierto');menu.setAttribute('aria-expanded',String(abierto));menu.setAttribute('aria-label',abierto?'Cerrar menú':'Abrir menú');menu.textContent=abierto?'✕':'☰';});
    nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('abierto');menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','Abrir menú');menu.textContent='☰';}));
    this.shadowRoot.querySelector('.cliente').addEventListener('click',()=>alert('El área de clientes estará disponible en una próxima fase.'));
  }
}
customElements.define('uco-header',UcoHeader);
