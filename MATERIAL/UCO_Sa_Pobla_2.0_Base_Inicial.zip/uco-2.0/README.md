# UCO Sa Pobla 2.0 — Prototipo inicial

Primera base de la nueva web: HTML, CSS, JavaScript con Web Components nativos.

## Cómo probarlo

Desde la carpeta `public`, iniciar un servidor local, por ejemplo:

```bash
python -m http.server 8000
```

Abrir `http://localhost:8000/`. También se puede utilizar Live Server de VS Code.

## Estado

- Portada, cabecera responsive, navegación y pie de página funcionales.
- Imágenes e identidad gráfica provisionales; no hay catálogo real, cuentas, carrito ni chatbot operativo.
- `public/api/index.php` es un marcador sin funciones de negocio.
- `private/` debe situarse **fuera del directorio público** en el servidor de producción.
- La integración con GESCOM se reserva para una fase posterior.

No subir a producción sin configurar la raíz pública y revisar seguridad y despliegue.
