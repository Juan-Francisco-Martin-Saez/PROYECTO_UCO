# UCO Sa Pobla 2.0 — Versión 0.6

Base de la versión 0.5, con ajustes focalizados de navegación y fotografías.

- Anclas Inicio, Familias, Selección, Sobre UCO, Pedidos y Contacto: desplazamiento calculado según la altura REAL de la cabecera fija, incluso al cambiar de dispositivo. La sección comienza justo debajo de la cabecera.
- Menú de escritorio más grande; navegación activa, hover e indicador adaptados al menú móvil corporativo.
- Slider con imágenes a sangre (`object-fit: cover`) ocupando toda la superficie, sin máscaras ni bandas. Puede recortarse parte de la foto para mantener el formato sin deformarla.
- Se conservan el contacto, pedidos de muestra, imágenes locales y estructura de Web Components de la versión anterior.
- Formulario de contacto de demostración: abre el cliente de correo mediante `mailto:`; todavía no envía al servidor.

Abrir `public/index.html` mediante Live Server o servir `public/` con un servidor HTTP local.

## Versión 0.7
Formulario con nombre y apellidos separados, correo y teléfono en segunda fila. Esquinas corporativas curvas superior izquierda e inferior derecha en fotografías, formulario, mapa, logo del pie y navegación; se conservan tamaños y colores hover.

## v0.8 — Botones con geometría corporativa
Todos los botones (CTA, formulario, slider, indicadores, menú hamburguesa móvil/tableta y controles compactos) usan curvas exclusivamente en la esquina superior izquierda y la inferior derecha. Se mantienen los tamaños, colores, transparencias y comportamientos de v0.7.


## Versión 0.9
- Selector de idioma ES/CA/EN con banderas; selección visual, traducciones pendientes.
- Selector compacto en barra superior de escritorio; dentro del menú hamburguesa en móvil y tableta.
- Textos de la barra superior agrupados a la izquierda en escritorio y centrados en pantallas pequeñas.
- Footer informativo centrado en móvil y tableta, sin alterar formulario ni mapa.
- Ajustes específicos del espacio inicial de Familias y Selección en móvil y tableta, respetando cabecera fija.


## Versión 1.1
- Botones de acción sin flechas decorativas; textos más visibles, negrita y centrados.
- Flechas del carrusel conservadas porque son controles de navegación funcionales.
- Icono en las cuatro tarjetas de familias: `img/uco-logo-blanco-calado.svg`, generado a partir de los trazados vectoriales EXACTOS del logotipo original; blanco en lugar del fondo azul, con letras y detalles originales perforados (transparentes).
- Logotipo corporativo original conservado sin modificaciones.
