# UCO Sa Pobla 2.0 - v1.8.1. Ejecutar desde la carpeta extraida con PHP detenido.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$source = Join-Path $PSScriptRoot 'archivos\public'
$target = Join-Path (Split-Path $PSScriptRoot -Parent) 'UCO-API'
if (!(Test-Path (Join-Path $target 'public\admin\admin.js')) -or !(Test-Path (Join-Path $target 'private\database\catalogo.sqlite'))) { throw "No se reconoce la instalacion en $target. No se ha modificado nada." }
$backupDir = Join-Path (Split-Path $target -Parent) 'UCO-Backups'
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
$backup = Join-Path $backupDir ('backup-previo-v181-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.zip')
Write-Host "Creando respaldo: $backup"
[System.IO.Compression.ZipFile]::CreateFromDirectory($target,$backup,[System.IO.Compression.CompressionLevel]::Optimal,$false)
$zip = [System.IO.Compression.ZipFile]::OpenRead($backup)
try {
  $names = @($zip.Entries | ForEach-Object { $_.FullName.Replace('\','/').TrimStart('/') })
  foreach ($required in @('public/index.html','public/admin/admin.js','public/api/admin.php','private/database/catalogo.sqlite')) { if ($names -notcontains $required) { throw "Falta en respaldo: $required" } }
  foreach ($entry in $zip.Entries) {
    if (!$entry.Name) { continue }
    $stream = $entry.Open()
    try { $stream.CopyTo([System.IO.Stream]::Null) } finally { $stream.Dispose() }
  }
} finally { $zip.Dispose() }
Write-Host 'Respaldo legible y comprobado. Aplicando archivos de programa...'
try {
  Get-ChildItem $source -Recurse -File | ForEach-Object {
    $relative = $_.FullName.Substring($source.Length).TrimStart('\','/')
    $rel = $relative.Replace('\','/')
    if ($rel -match '^img/(usuarios|productos)/') { return }
    $dest = Join-Path (Join-Path $target 'public') $relative
    New-Item -ItemType Directory -Force -Path (Split-Path $dest -Parent) | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $dest -Force
  }
  Write-Host 'VERSION 1.8.1 APLICADA. SQLite, usuarios y fotografias conservados.' -ForegroundColor Green
} catch {
  Write-Warning 'Fallo al copiar. Restaurando desde el respaldo...'
  [System.IO.Compression.ZipFile]::ExtractToDirectory($backup,(Join-Path $backupDir ('recuperacion-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))))
  Write-Error "Actualizacion incompleta. El respaldo esta en $backup. Se ha extraido una copia de recuperacion en UCO-Backups; restaura antes de iniciar PHP. Error: $_"
}
