<?php
declare(strict_types=1);
ini_set('display_errors','0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
ini_set('session.use_strict_mode','1');
session_name('UCOADMIN');
session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','samesite'=>'Strict','path'=>'/']);
session_start();
function replyOrders(array $body,int $status=200):never{http_response_code($status);echo json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
try{
 if($_SERVER['REQUEST_METHOD']!=='GET')replyOrders(['error'=>'Método no permitido'],405);
 $staffId=(int)($_SESSION['uco_user_id']??0);
 if($staffId<1)replyOrders(['error'=>'Inicia sesión en administración'],401);
 $db=new PDO('sqlite:'.dirname(__DIR__,2).'/private/database/catalogo.sqlite',null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
 $db->exec('PRAGMA busy_timeout=5000');$db->exec('PRAGMA foreign_keys=ON');
 require_once dirname(__DIR__,2).'/private/identity.php';
 $q=$db->prepare('SELECT id,role,active,password_hash FROM admin_users WHERE id=?');
 $q->execute([$staffId]);$staff=$q->fetch();
 if(!$staff||(int)$staff['active']!==1||!in_array($staff['role'],['admin','manager'],true)||!hash_equals((string)($_SESSION['uco_auth_stamp']??''),hash('sha256',(string)$staff['password_hash']))||!ucoIdentitySessionValid($db,'staff',$staffId,$_SESSION['uco_identity_id']??null))replyOrders(['error'=>'Sesión no válida'],403);
 // Esta fase es estrictamente de consulta. No se permiten modificaciones.
 $q=$db->query("SELECT o.id,o.customer_id,c.company AS customer,o.status AS payment_order_state,o.payment_status,o.subtotal_cents,o.created_at,
 p.state AS simulation_state,p.method AS payment_method,p.total_cents,
 f.state AS fulfillment_state,f.updated_at AS fulfillment_updated_at
 FROM uco_orders o JOIN customers c ON c.id=o.customer_id
 LEFT JOIN uco_simulated_payments p ON p.order_id=o.id
 LEFT JOIN uco_order_fulfillment f ON f.order_id=o.id
 ORDER BY o.id DESC LIMIT 300");
 $rows=$q->fetchAll();
 $lines=$db->prepare('SELECT sku,name,unit,quantity,unit_price_cents,line_cents FROM uco_order_lines WHERE order_id=? ORDER BY id');
 foreach($rows as &$row){
  $lines->execute([(int)$row['id']]);$row['lines']=$lines->fetchAll();
  $row['payment_confirmed']=($row['payment_order_state']==='paid'&&$row['payment_status']==='simulated_approved'&&$row['simulation_state']==='approved');
 }unset($row);
 replyOrders(['orders'=>$rows,'read_only'=>true]);
}catch(Throwable $e){error_log('UCO Pedidos 2B: '.$e->getMessage());replyOrders(['error'=>'No se pudo consultar el listado de pedidos. Comprueba que has aplicado la Fase 2A.'],500);}
