/* Presentación del catálogo y seguridad del cliente. Sin llamadas HTTP. */
function shortClientName(name){
 const original=String(name||'').trim();
 let result=original.replace(/\s*[·|–—]\s*/g,' ').replace(/\s*\([^)]*\b(?:KG|GR|G|ML|L|UDS?|UNIDADES?)\b[^)]*\)/gi,' ')
 .replace(/\b(?:\d+\s*[x×*]\s*)?\d+(?:[.,]\d+)?\s*(?:KG|KGS|GR|G|ML|L|UDS?|UNIDADES?)\b/gi,' ')
 .replace(/\b(?:CAJA|BOLSA|CUBO|BANDEJA|PAQUETE|SACO|FORMATO)\s*(?:DE\s*)?$/gi,' ')
 .replace(/\s+/g,' ').trim();
 // Keep distinguishing preparation and cut; shorten only redundant prefixes.
 result=result.replace(/^(?:BASE PARA|PREPARADO PARA)\s+/i,'').replace(/\b(?:APROXIMADAMENTE|APROX\.?)\b/gi,'').replace(/\s+/g,' ').trim();
 return result||original;
}
export class UcoClientProductList extends HTMLElement {
 renderProducts(products,esc){this.innerHTML=products.map(p=>{const src=String(p.image||'');const image=/^\.\/img\/(?:productos\/[a-zA-Z0-9_-]+\.webp|[0-9]{2}\.webp)$/.test(src)?'../'+src.slice(2):'../img/00.webp';return `<article class="client-card"><div class="client-photo"><img src="${esc(image)}" alt="${esc(p.name)}" loading="lazy"></div><div class="client-card-content"><small>${esc(p.family)}</small><h3 class="uco-client-short-name" title="${esc(p.name)}" aria-label="${esc(p.name)}">${esc(shortClientName(p.name))}</h3><p class="uco-client-product-meta" title="${esc(p.name)}">${esc(p.unit||'unidad')} · Ref. ${esc(p.sku)}</p><small class="uco-client-availability">${+p.stock>0?'Disponible':'Consultar disponibilidad'}</small><div class="uco-client-price-row">${p.price_cents!==null&&+p.stock>0?`<label class="uco-client-units">Unidades<input type="number" inputmode="numeric" min="1" max="99999" step="1" value="1" data-product-units="${Number(p.id)}" aria-label="Unidades de ${esc(p.name)}"></label>`:'<span></span>'}<strong class="client-price ${p.price_cents===null?'missing':''}">${p.price_cents===null?'Consultar precio':(p.price_cents/100).toLocaleString('es-ES',{style:'currency',currency:'EUR'})}</strong></div>${p.price_cents!==null&&+p.stock>0?`<button class="primary uco-add-cart" type="button" data-cart-add="${Number(p.id)}">Añadir al carrito</button>`:""}</div></article>`}).join('')||'<p>No se encontraron productos.</p>';}
}
export class UcoClientPasswordContent extends HTMLElement {
 connectedCallback(){if(!this.hasChildNodes())this.innerHTML=`<div class="modal"><header><h2>Mi seguridad</h2><button type="button" class="close" id="close">×</button></header><form class="security-form"><div class="field"><label>Contraseña actual</label><input type="password" name="old_password" required autocomplete="current-password"></div><div class="field"><label>Nueva contraseña</label><input type="password" name="new_password" required minlength="12" autocomplete="new-password"></div><div class="field"><label>Confirmar contraseña</label><input type="password" name="confirm" required minlength="12" autocomplete="new-password"></div><p class="alert" id="err"></p><div class="buttons"><button type="button" class="secondary" id="cancel">Cancelar</button><button type="submit" class="primary">Guardar contraseña</button></div></form></div>`;}
}
for(const [tag,cls] of [['uco-client-product-list',UcoClientProductList],['uco-client-password-content',UcoClientPasswordContent]])if(!customElements.get(tag))customElements.define(tag,cls);
