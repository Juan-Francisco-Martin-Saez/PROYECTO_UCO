<?php
declare(strict_types=1);
ini_set('display_errors','0');header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');
ini_set('session.use_strict_mode','1');session_name('UCOADMIN');session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','samesite'=>'Strict','path'=>'/']);session_start();
function respond($v,int $code=200):never{http_response_code($code);echo json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function norm(string $s):string{$s=mb_strtolower($s,'UTF-8');if(class_exists('Normalizer'))$s=Normalizer::normalize($s,Normalizer::FORM_D);return strtr($s,['á'=>'a','à'=>'a','ä'=>'a','â'=>'a','é'=>'e','è'=>'e','ë'=>'e','ê'=>'e','í'=>'i','ì'=>'i','ï'=>'i','î'=>'i','ó'=>'o','ò'=>'o','ö'=>'o','ô'=>'o','ú'=>'u','ù'=>'u','ü'=>'u','û'=>'u']);}
function db():PDO{$db=new PDO('sqlite:'.dirname(__DIR__,2).'/private/database/catalogo.sqlite',null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);$db->exec('PRAGMA foreign_keys=ON');$db->exec('PRAGMA busy_timeout=5000');return $db;}
function authorized():bool{return ($_SESSION['uco_admin']??false)===true;}
function csrf():void{if(!hash_equals((string)($_SESSION['csrf']??''),(string)($_SERVER['HTTP_X_CSRF_TOKEN']??'')))respond(['error'=>'Sesión no válida. Actualiza la página.'],403);}
$action=(string)($_GET['action']??'session');$method=$_SERVER['REQUEST_METHOD'];
try{
if($action==='session'&&$method==='GET')respond(['authenticated'=>authorized(),'csrf'=>authorized()?($_SESSION['csrf']??''):null]);
if($action==='login'&&$method==='POST'){
 $hash=(string)(getenv('UCO_ADMIN_PASSWORD_HASH')?:'');$password=(string)($_POST['password']??'');
 if($hash===''||!password_verify($password,$hash)){usleep(400000);respond(['error'=>$hash===''?'Configura UCO_ADMIN_PASSWORD_HASH en el servidor.':'Credenciales incorrectas.'],401);}
 session_regenerate_id(true);$_SESSION['uco_admin']=true;$_SESSION['csrf']=bin2hex(random_bytes(32));respond(['authenticated'=>true,'csrf'=>$_SESSION['csrf']]);
}
if(!authorized())respond(['error'=>'Acceso no autorizado'],401);
if($action==='logout'&&$method==='POST'){csrf();$_SESSION=[];session_destroy();respond(['ok'=>true]);}
$db=db();
if($action==='list'&&$method==='GET'){
 $q=trim((string)($_GET['q']??''));$family=(string)($_GET['family']??'');$active=(string)($_GET['active']??'');$stock=(string)($_GET['stock']??'');
 if(mb_strlen($q)>100)respond(['error'=>'Búsqueda demasiado larga'],400);
 $where=[];$args=[];
 if($q!==''){$where[]="p.search_text LIKE :q ESCAPE '!'";$args[':q']='%'.str_replace(['!','%','_'],['!!','!%','!_'],norm($q)).'%';}
 if($family!==''){$where[]='c.slug=:family';$args[':family']=$family;}
 if(in_array($active,['0','1'],true)){$where[]='p.active=:active';$args[':active']=(int)$active;}
 if($stock==='yes')$where[]='p.stock>0';if($stock==='no')$where[]='p.stock=0';
 $filter=$where?' WHERE '.implode(' AND ',$where):'';
 $sql=' FROM products p JOIN categories c ON c.id=p.category_id'.$filter;
 $stmt=$db->prepare('SELECT p.id,p.sku,p.name,p.image,p.active,p.stock,p.notes,p.created_at,p.updated_at,c.slug AS category,c.name AS family'.$sql.' ORDER BY p.created_at DESC,p.id DESC LIMIT 2000');$stmt->execute($args);
 $categories=$db->query('SELECT id,slug,name FROM categories WHERE active=1 ORDER BY sort_order,id')->fetchAll();
 $totals=$db->query('SELECT COUNT(*) AS total,COALESCE(SUM(active),0) AS active,COALESCE(SUM(CASE WHEN active=0 THEN 1 ELSE 0 END),0) AS inactive FROM products')->fetch();
 respond(['products'=>$stmt->fetchAll(),'categories'=>$categories,'totals'=>$totals]);
}
if($action==='save'&&$method==='POST'){
 csrf();$id=(int)($_POST['id']??0);$sku=trim((string)($_POST['sku']??''));$name=trim((string)($_POST['name']??''));$cat=(int)($_POST['category_id']??0);$active=(string)($_POST['active']??'1')==='1'?1:0;$stock=filter_var($_POST['stock']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>0,'max_range'=>100000000]]);$notes=trim((string)($_POST['notes']??''));
 if($sku===''||mb_strlen($sku)>60||$name===''||mb_strlen($name)>160||$stock===false||mb_strlen($notes)>350||substr_count($notes,"\n")>2)respond(['error'=>'Revisa código, nombre, stock y observaciones (máximo 3 líneas y 350 caracteres).'],422);
 if(!$db->prepare('SELECT 1 FROM categories WHERE id=? AND active=1')->execute([$cat]))respond(['error'=>'Familia inválida'],422);
 $check=$db->prepare('SELECT id FROM categories WHERE id=? AND active=1');$check->execute([$cat]);if(!$check->fetch())respond(['error'=>'Selecciona una familia válida'],422);
 $photo=$_FILES['photo']??null;$image=null;
 if($photo&&$photo['error']!==UPLOAD_ERR_NO_FILE){
  if($photo['error']!==UPLOAD_ERR_OK||$photo['size']>12*1024*1024)respond(['error'=>'Imagen inválida o superior a 12 MB'],422);
  if(!extension_loaded('gd'))respond(['error'=>'El servidor necesita la extensión GD para optimizar imágenes'],503);
  $info=@getimagesize($photo['tmp_name']);if(!$info||$info[0]>10000||$info[1]>10000||$info[0]*$info[1]>40000000||!in_array($info[2],[IMAGETYPE_JPEG,IMAGETYPE_PNG,IMAGETYPE_WEBP],true))respond(['error'=>'Usa JPG, PNG o WebP válidos'],422);
  $src=match($info[2]){IMAGETYPE_JPEG=>@imagecreatefromjpeg($photo['tmp_name']),IMAGETYPE_PNG=>@imagecreatefrompng($photo['tmp_name']),IMAGETYPE_WEBP=>@imagecreatefromwebp($photo['tmp_name'])};if(!$src)respond(['error'=>'No se pudo leer la imagen'],422);
  $dst=imagecreatetruecolor(960,720);$bg=imagecolorallocate($dst,248,249,246);imagefill($dst,0,0,$bg);$scale=min(960/$info[0],720/$info[1],1);$w=max(1,(int)round($info[0]*$scale));$h=max(1,(int)round($info[1]*$scale));imagecopyresampled($dst,$src,(int)((960-$w)/2),(int)((720-$h)/2),0,0,$w,$h,$info[0],$info[1]);imagedestroy($src);
  $dir=dirname(__DIR__).'/img/productos';if(!is_dir($dir)&&!mkdir($dir,0755,true))respond(['error'=>'No se pudo crear la carpeta de imágenes'],503);
  $filename=bin2hex(random_bytes(16)).'.webp';if(!imagewebp($dst,$dir.'/'.$filename,88)){imagedestroy($dst);respond(['error'=>'Error al guardar la fotografía'],503);}imagedestroy($dst);$image='./img/productos/'.$filename;
 }
 $search=norm($sku.' '.$name);
 try{
  if($id>0){$old=$db->prepare('SELECT image FROM products WHERE id=?');$old->execute([$id]);$prev=$old->fetch();if(!$prev)respond(['error'=>'Producto inexistente'],404);$stmt=$db->prepare('UPDATE products SET sku=?,name=?,category_id=?,active=?,stock=?,notes=?,search_text=?,image=COALESCE(?,image),updated_at=CURRENT_TIMESTAMP WHERE id=?');$stmt->execute([$sku,$name,$cat,$active,$stock,$notes,$search,$image,$id]);}
  else{$stmt=$db->prepare("INSERT INTO products(sku,name,category_id,active,stock,notes,search_text,image,is_demo) VALUES(?,?,?,?,?,?,?,?,0)");$stmt->execute([$sku,$name,$cat,$active,$stock,$notes,$search,$image]);$id=(int)$db->lastInsertId();}
 }catch(PDOException $e){if($image)@unlink(dirname(__DIR__).'/'.substr($image,2));if(str_contains($e->getMessage(),'UNIQUE'))respond(['error'=>'Ese código de producto ya existe'],409);throw $e;}
 respond(['ok'=>true,'id'=>$id]);
}
respond(['error'=>'Operación no permitida'],405);
}catch(Throwable $e){error_log('UCO admin: '.$e->getMessage());respond(['error'=>'No se pudo completar la operación'],500);}
