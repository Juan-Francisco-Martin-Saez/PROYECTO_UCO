<?php
// Archivo PRIVADO: no subir a Git ni compartir.
// Sustituye el texto entre comillas por tu clave secreta de OpenAI.
return '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';
