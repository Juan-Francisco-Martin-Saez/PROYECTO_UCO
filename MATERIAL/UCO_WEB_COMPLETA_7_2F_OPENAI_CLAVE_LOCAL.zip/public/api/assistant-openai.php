<?php
declare(strict_types=1);
/** UCO: conexion OpenAI independiente, protegida. Sin acceso a carrito, pagos o escrituras. */
ini_set('display_errors','0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
function outAI(array $x,int $code=200):never {http_response_code($code);echo json_encode($x,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
if(($_SERVER['REQUEST_METHOD']??'')!=='POST')outAI(['ok'=>false,'error'=>'Método no permitido'],405);
if(!str_contains((string)($_SERVER['CONTENT_TYPE']??''),'application/json'))outAI(['ok'=>false,'error'=>'Formato incorrecto'],415);
if((int)($_SERVER['CONTENT_LENGTH']??0)>12000)outAI(['ok'=>false,'error'=>'Solicitud demasiado grande'],413);
$body=json_decode(file_get_contents('php://input'),true);
$q=trim((string)($body['message']??''));
if(!is_array($body)||mb_strlen($q,'UTF-8')<2||mb_strlen($q,'UTF-8')>300)outAI(['ok'=>false,'error'=>'Consulta inválida'],422);
$conf=require dirname(__DIR__,2).'/private/config/openai-protected.php';
$key=trim((string)(getenv('OPENAI_API_KEY') ?: ''));
// Alternativa permanente para desarrollo local, fuera de public/.
// La variable de entorno tiene prioridad si existe.
if($key===''){
    $secretFile=dirname(__DIR__,2).'/private/config/openai-local-secret.php';
    if(is_file($secretFile)){
        $localKey=require $secretFile;
        if(is_string($localKey))$key=trim($localKey);
    }
}
if($key==='' || $key==='PEGA_AQUI_TU_API_KEY')$key='';
if(!$key||!function_exists('curl_init'))outAI(['ok'=>false,'unavailable'=>true,'error'=>'OpenAI no configurado'],503);
// No se envían historiales, cookies, identificadores personales ni tarifas privadas.
// El modelo interpreta lenguaje; NUNCA es fuente autorizada de precios o acciones comerciales.
$payload=['prompt'=>['id'=>$conf['prompt_id'],'version'=>$conf['prompt_version']],
 'input'=>[['role'=>'user','content'=>[['type'=>'input_text','text'=>$q]]]],
 'store'=>false,'max_output_tokens'=>700];
$ch=curl_init('https://api.openai.com/v1/responses');
curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$key,'Content-Type: application/json'],CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE),CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>($conf['timeout_seconds']??18),CURLOPT_CONNECTTIMEOUT=>5]);
$raw=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
if($raw===false||$status<200||$status>=300){error_log('[UCO OpenAI] HTTP '.$status.' '.$err);outAI(['ok'=>false,'unavailable'=>true,'error'=>'Asistente avanzado temporalmente no disponible'],503);}
$result=json_decode($raw,true);
if(!is_array($result))outAI(['ok'=>false,'unavailable'=>true,'error'=>'Respuesta inválida'],502);
$text='';
foreach(($result['output']??[]) as $entry)foreach(($entry['content']??[]) as $part)if(($part['type']??'')==='output_text')$text.=(string)($part['text']??'');
$parsed=json_decode($text,true);
if(!is_array($parsed)||!isset($parsed['response'])||!is_string($parsed['response']))outAI(['ok'=>false,'unavailable'=>true,'error'=>'Formato del prompt incompatible; requiere revisión autorizada'],502);
// El texto de OpenAI no se muestra como presupuesto ni precio. Cualquier cifra monetaria
// requiere la API comercial autenticada existente. Rechazar respuestas con importes.
$reply=trim($parsed['response']);
if($reply===''||mb_strlen($reply,'UTF-8')>1800||preg_match('/(?:\d[\d.,]*\s*€|€\s*\d|\d[\d.,]*\s*euros?)/iu',$reply))outAI(['ok'=>false,'unavailable'=>true,'error'=>'Respuesta pendiente de validación comercial'],422);
outAI(['ok'=>true,'response'=>$reply,'status'=>$parsed['status']??'needs_clarification','source'=>'openai_prompt_v2','commercial_verified'=>false]);
