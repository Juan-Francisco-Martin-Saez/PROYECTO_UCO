<?php
// Archivo PRIVADO: no subir a Git ni compartir.
// Sustituye el texto entre comillas por tu clave secreta de OpenAI.
return 'PEGA_AQUI_TU_API_KEY';
