# Restauración del chatbot administrativo

Restaurado `public/admin/index.html` exactamente de la versión anterior. Se mantienen los cambios públicos de botones compactos y Nuevo chat. `prepedido.js` excluye `data-area="admin"`, de modo que los nuevos botones no se añaden en administración. Base SQLite intacta.
