# Fase 7.2E.6 — Priorización de resultados

Se ordenan primero los nombres exactos, luego los que empiezan por la consulta, luego los que la contienen y finalmente las coincidencias por atributos/descripción/categoría. La referencia exacta mantiene su ruta prioritaria. Los filtros AND, formatos, sinónimos y el límite de 12 resultados no cambian. No se modifican datos ni operaciones comerciales.

Validar en PHP con SQLite y mbstring antes de producción.
