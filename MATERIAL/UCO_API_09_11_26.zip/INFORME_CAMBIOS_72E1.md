# Fase 7.2E.1 — Búsqueda exacta por referencia

- El endpoint `public/api/assistant-catalog-71a.php` detecta referencias numéricas de 6 a 14 cifras y consulta el campo `sku` por igualdad exacta, preservando ceros iniciales.
- Las búsquedas por nombre siguen usando el filtrado anterior, sin ampliar relaciones semánticas ni introducir coincidencias ambiguas.
- Nueva prueba estática `tests/test-assistant-catalog-reference-72e1.php`.
- No se han modificado bases de datos, tarifas, carrito, administración ni interfaces.
- Pendiente: prueba integrada del endpoint con PHP PDO SQLite en el alojamiento.
