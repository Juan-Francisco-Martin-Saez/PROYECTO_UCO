# Fase 7.2E.4 — Corrección de búsquedas solo por formato

- Corregido el caso en que una consulta incluye únicamente un peso o un tipo de envase, sin palabras de producto: antes se devolvía vacío o se generaba SQL con `AND ORDER BY`.
- Los filtros SQL ahora se ensamblan como una lista de condiciones válidas, sin introducir conjunciones sobrantes.
- Se conserva el límite de 12 resultados, las reglas de sinónimos, referencias y filtros sobre datos registrados en `uco_presentaciones`.
- Añadido test independiente de análisis de formatos (`tests/test-assistant-format-query-72e4.php`).
- No se modifica ninguna base de datos, precio, pedido, carrito o configuración del prompt.

## Limitaciones de verificación
Se valida la sintaxis PHP, la integridad ZIP y la suite JS disponible. En este entorno PHP no tiene las extensiones `pdo_sqlite` y `mbstring`; no se puede certificar aquí una prueba HTTP real con la base de datos. Antes de producción, ejecutar los tests y probar en un entorno de staging con esas extensiones.
