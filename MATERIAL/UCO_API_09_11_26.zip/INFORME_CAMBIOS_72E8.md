# Fase 7.2E.8 — Regresión y priorización de consultas naturales

- Corregida la ponderación del nombre para usar los términos de producto después de retirar expresiones de cortesía.
- Se mantienen sin cambios las referencias, el filtrado de formatos, los límites de resultados y el JSON público.
- Pruebas SQLite de solo lectura: 10/10 superadas (ver ejecución de test-assistant-catalog-integration-72e8.py).
- Sintaxis PHP: No syntax errors detected in /mnt/data/uco_72e8_new/public/api/assistant-catalog-71a.php
- Pruebas JS: 22/22 superadas.
- No se ha ejecutado el endpoint PHP con PDO SQLite y mbstring, extensiones no disponibles en este entorno. No desplegar sin pruebas HTTP en staging.
