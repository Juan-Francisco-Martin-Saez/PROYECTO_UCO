# Fase 7.2E.2 — Sinónimos aprobados en la búsqueda del catálogo

- El endpoint `public/api/assistant-catalog-71a.php` consulta los sinónimos con estado `approved` en el diccionario existente.
- Alternativas OR dentro de cada término; todos los términos originales siguen siendo obligatorios (AND).
- Se mantienen las búsquedas exactas por SKU y los ceros iniciales.
- Si falla la lectura del diccionario, continúa la búsqueda básica sin sinónimos.
- No se añaden equivalencias inventadas ni se modifica ninguna base de datos.
- Pruebas: sintaxis PHP, regresión de referencias y prueba estática de sinónimos.
- Pendiente: pruebas de extremo a extremo con PHP `pdo_sqlite` y `mbstring`, y evaluación con consultas reales.

## Instalación
Aplicar el parche sobre la versión 7.2E.1. La web completa incluye la copia de SQLite del ZIP de desarrollo; **no sobrescribir la base de datos activa del servidor**.
