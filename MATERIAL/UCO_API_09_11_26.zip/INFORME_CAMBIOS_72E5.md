# Fase 7.2E.5 — Detección explícita de coincidencias y ambigüedad

## Cambio
El endpoint `public/api/assistant-catalog-71a.php` conserva `ok` e `items` y añade:
- `match_status`: `none`, `unique` o `multiple` según el número de productos devueltos.
- `has_more`: `true` cuando existen más de 12 coincidencias (se consulta una fila adicional, sin exponer más de 12).

Para referencias exactas se conserva la búsqueda por SKU y el límite existente. Los campos nuevos son informativos: **no seleccionan automáticamente un producto** ni modifican el presupuesto o el carrito. El consumidor debe preguntar por formato/referencia si `match_status=multiple`.

## Alcance y límites
No se alteran bases de datos, diccionario, precios, pedidos, pagos ni el prompt de OpenAI. El entorno de pruebas local no dispone de extensiones PHP `mbstring` ni `pdo_sqlite`, por lo que no se ha podido ejecutar el endpoint contra SQLite; comprobarlo en staging antes de producción.
