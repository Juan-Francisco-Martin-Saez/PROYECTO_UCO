# Fase 7.2E.3 — Filtros verificables de peso y envase

- El buscador reconoce pesos en kg/g y presentaciones explícitas `6x1 kg` o `6×1 kg`.
- Filtra exclusivamente mediante los campos registrados en `uco_presentaciones`; nunca infiere envases a partir del peso total.
- Para presentaciones desglosadas exige `estado=desglosado`, número de envases y peso individual coincidentes.
- Las palabras `caja`, `bolsa`, `paquete` se contrastan con `tipo_envase` registrado.
- La referencia SKU exacta sigue teniendo prioridad sobre filtros de formato.
- No se alteran SQLite, precios, pedidos, carrito ni administración.
- Limitación: presentaciones sin desglose o sin tipo de envase registrado no se pueden confirmar con estos filtros; no se muestran como coincidencias verificadas.
- Verificación pendiente: pruebas de extremo a extremo en entorno con PHP, PDO SQLite y mbstring. No desplegar sin probar sobre una copia.
