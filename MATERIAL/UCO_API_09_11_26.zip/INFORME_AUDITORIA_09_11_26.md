# UCO Sa Pobla 2.0 — Consolidación de pruebas 09/11/2026

Base: UCO_API_09_11_26.zip.

## Cambios
Solo se actualizaron las cuatro pruebas de integración estática:
- tests/test-assistant-budget-71u.js: separa presupuesto efímero de prepedido persistente; conserva reinicio de contexto sin borrar prepedido.
- tests/test-assistant-cart-relative-71y.js: valida el enrutamiento contextual y los límites del carrito.
- tests/test-assistant-client-shortcuts-71t1.js: valida navegación nativa y carga versionada sin exigir un número de versión obsoleto.
- tests/test-assistant-orders-71h.js: valida las rutas autenticadas de pedidos y documentos.

## Resultados
22/22 pruebas JavaScript pasan con Node.js v22.16.0. Son pruebas estáticas/de integración del código; no equivalen a pruebas end-to-end con servidor y navegador.

## Sin modificar
Código de producción, interfaz, SQLite, datos de clientes, administración, tarifas, pedidos y pagos.

## Pendiente
Ejecutar pruebas PHP en entorno con extensiones mbstring y pdo_sqlite; probar autenticación, búsquedas, prepedido, carrito y documentos con datos de prueba en servidor. Auditar diferencias de versiones entre home y clientes.

## Instalación
El ZIP completo incluye el proyecto íntegro y las cuatro pruebas actualizadas. Si se usa sobre un servidor en producción, NO sobrescribir bases de datos ni datos dinámicos: el ZIP es una instantánea de desarrollo. El parche contiene solo las cuatro pruebas y este informe.
