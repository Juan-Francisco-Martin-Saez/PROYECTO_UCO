# UCO Sa Pobla 2.0 — Prototipo v0.4

Abre `public/index.html` mediante Live Server o un servidor web local.

- Cabecera sticky con navegación anclada y compensación de altura.
- Secciones de altura mínima igual a la pantalla disponible; las secciones largas crecen naturalmente.
- Slider y fotografías con `object-fit: contain`, sin ampliaciones forzadas, y fundido de bordes en la portada.
- Titulares Space Grotesk, textos Manrope; diseño responsive.
- Se conserva el contenido gráfico, estructura y API del ZIP original. No existe aún catálogo dinámico ni sistema de pedidos.
