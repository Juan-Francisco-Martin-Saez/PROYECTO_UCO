/* Datos fiscales del emisor. Rellenar únicamente con información oficial verificada.
   Se muestran en el encabezado de cada página del justificante. */
export const ucoReceiptCompany={
 fiscalName:'UCO SA POBLA',
 taxId:'',
 address:'',
 postalCode:'',
 city:'',
 province:'',
 phone:'',
 email:''
};
