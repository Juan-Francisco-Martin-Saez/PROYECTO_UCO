/* Fase 7.0 — widget global de ayuda guiada, sin conexión a IA ni operaciones bancarias. */
(()=>{'use strict';
if(document.getElementById('uco-assistant-root'))return;
const area=document.currentScript?.dataset.area||'public';
const store='uco_assistant_v70';const MAX=24;const now=Date.now();
let state={messages:[],closedAt:0,invitedAt:0};
try{const x=JSON.parse(sessionStorage.getItem(store)||'{}');if(x&&typeof x==='object'){state={...state,...x};if(!Array.isArray(state.messages))state.messages=[];}}catch{}
const save=()=>{try{sessionStorage.setItem(store,JSON.stringify({...state,messages:state.messages.slice(-MAX)}))}catch{}};
const root=document.createElement('div');root.id='uco-assistant-root';root.setAttribute('data-area',area);
const launch=document.createElement('button');launch.type='button';launch.className='uco-ai-launch';launch.setAttribute('aria-expanded','false');launch.setAttribute('aria-controls','uco-ai-panel');launch.innerHTML='<span aria-hidden="true">🤖</span><span>Asistente UCO</span>';
const panel=document.createElement('section');panel.id='uco-ai-panel';panel.className='uco-ai-panel';panel.hidden=true;panel.setAttribute('aria-label','Asistente UCO');
const head=document.createElement('div');head.className='uco-ai-head';const heading=document.createElement('strong');heading.textContent=area==='admin'?'Ayuda administrativa':area==='client'?'Asistente de clientes':'Asistente UCO';const minimize=document.createElement('button');minimize.type='button';minimize.className='uco-ai-minimize';minimize.textContent='−';minimize.setAttribute('aria-label','Minimizar asistente');const close=document.createElement('button');close.type='button';close.className='uco-ai-close';close.textContent='Cerrar ×';const dragHandle=document.createElement('span');dragHandle.className='uco-ai-drag';dragHandle.textContent='⋮⋮';dragHandle.title='Arrastra para mover el asistente';head.append(dragHandle,heading,minimize,close);
const stage=document.createElement('div');stage.className='uco-ai-stage';
const robot=document.createElement('div');robot.className='uco-ai-robot';robot.setAttribute('aria-hidden','true');
robot.innerHTML=`<svg viewBox="0 0 270 230" role="img" aria-label="Robot azul UCO"><defs><linearGradient id="uco-ai-blue" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#68b9e8"/><stop offset=".53" stop-color="#2775b5"/><stop offset="1" stop-color="#153b80"/></linearGradient><linearGradient id="uco-ai-metal"><stop stop-color="#b9d9e8"/><stop offset=".5" stop-color="#eff9ff"/><stop offset="1" stop-color="#8ab4ce"/></linearGradient></defs><path d="M135 20V9" stroke="#9cc9df" stroke-width="6" stroke-linecap="round"/><circle cx="135" cy="9" r="7" fill="#a9e13f"/><rect x="72" y="31" width="126" height="106" rx="26" fill="url(#uco-ai-blue)" stroke="#142f60" stroke-width="6"/><path d="M87 49h96" stroke="#a5d6f0" stroke-width="5" opacity=".65"/><rect x="84" y="58" width="102" height="51" rx="15" fill="#102950"/><circle cx="109" cy="83" r="12" fill="#a9e13f"/><circle cx="161" cy="83" r="12" fill="#a9e13f"/><circle cx="109" cy="83" r="5" fill="#f4ffe6"/><circle cx="161" cy="83" r="5" fill="#f4ffe6"/><rect class="uco-ai-mouth" x="115" y="116" width="40" height="8" rx="4" fill="#a9e13f"/><rect x="58" y="75" width="15" height="29" rx="7" fill="url(#uco-ai-metal)"/><rect x="197" y="75" width="15" height="29" rx="7" fill="url(#uco-ai-metal)"/><rect x="88" y="139" width="94" height="78" rx="19" fill="url(#uco-ai-blue)" stroke="#142f60" stroke-width="6"/><rect x="105" y="154" width="60" height="39" rx="9" fill="#14365f" stroke="#9ac8e2" stroke-width="2"/><text x="135" y="180" font-family="Arial Black,Space Grotesk,sans-serif" font-size="24" font-weight="900" text-anchor="middle" fill="#fff" letter-spacing="-1">UCO</text><path d="M87 157L62 170v30M183 157l25 13v30" stroke="#266aab" stroke-width="17" stroke-linecap="round"/><circle cx="61" cy="202" r="11" fill="url(#uco-ai-metal)"/><circle cx="209" cy="202" r="11" fill="url(#uco-ai-metal)"/><path d="M112 217v10m46-10v10" stroke="#173e78" stroke-width="12" stroke-linecap="round"/></svg>`;
const speech=document.createElement('div');speech.className='uco-ai-speech';speech.setAttribute('aria-live','polite');
stage.append(robot,speech);
const messages=document.createElement('div');messages.className='uco-ai-messages';messages.setAttribute('role','log');messages.setAttribute('aria-live','polite');
const actions=document.createElement('div');actions.className='uco-ai-actions';
const form=document.createElement('form');form.className='uco-ai-form';const input=document.createElement('input');input.type='text';input.maxLength=300;input.placeholder='Escribe tu consulta…';input.setAttribute('aria-label','Consulta al asistente');input.autocomplete='off';const send=document.createElement('button');send.type='submit';send.textContent='Enviar';form.append(input,send);
const foot=document.createElement('div');foot.className='uco-ai-foot';foot.textContent='Versión inicial: ayuda guiada. No procesa pedidos ni pagos.';
panel.append(head,stage,messages,actions,form,foot);
const hint=document.createElement('div');hint.className='uco-ai-hint';hint.hidden=true;const hintText=document.createElement('span');hintText.textContent='¿Necesitas ayuda? Estoy aquí cuando quieras.';const hintDismiss=document.createElement('button');hintDismiss.type='button';hintDismiss.textContent='×';hintDismiss.setAttribute('aria-label','Descartar sugerencia');hint.append(hintText,hintDismiss);root.append(panel,hint,launch);document.body.append(root);
let talkingTimer=null;
function speak(text){
 speech.textContent=text;speech.hidden=false;robot.classList.add('is-speaking');
 clearTimeout(talkingTimer);
 const duration=Math.min(8000,Math.max(2000,text.length*42));
 talkingTimer=setTimeout(()=>{robot.classList.remove('is-speaking');speech.hidden=true},duration);
}
const greeting=area==='admin'?'Puedo orientarte por las secciones de administración. No realizo cambios por ti.':area==='client'?'Puedo ayudarte a localizar productos y explicarte cómo preparar tu pedido.':'Puedo ayudarte a encontrar productos y orientarte sobre cómo comprar en UCO.';
function append(who,text,persist=true){const item=document.createElement('div');item.className='uco-ai-msg';item.dataset.who=who;item.textContent=text;messages.append(item);messages.scrollTop=messages.scrollHeight;if(who==='bot')speak(text);if(persist){state.messages.push({who,text});state.messages=state.messages.slice(-MAX);save()}}
if(state.messages.length){state.messages.slice(-MAX).forEach(m=>{if((m.who==='user'||m.who==='bot')&&typeof m.text==='string')append(m.who,m.text,false)})}else append('bot',greeting);
const shortcuts=area==='admin'?[['Pedidos','Para revisar pedidos, entra en la sección Pedidos. Esta versión no puede modificarlos.'],['Clientes','Gestiona los clientes desde su sección administrativa.'],['Pagos','Consulta Control de pagos para revisar estados. El asistente no puede ejecutar cobros.']]:[['Catálogo','Puedes explorar el catálogo y utilizar sus filtros para localizar productos.'],['Mi pedido','Revisa el carrito y confirma los datos en el proceso normal de compra.'],['Ayuda','Cuéntame qué necesitas. En esta primera versión puedo orientarte, pero aún no interpreto pedidos automáticamente.']];
shortcuts.forEach(([label,answer])=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.addEventListener('click',()=>{append('user',label);append('bot',answer)});actions.append(b)});
function open(){panel.hidden=false;hint.hidden=true;launch.setAttribute('aria-expanded','true');root.classList.add('uco-ai-open');input.focus()}
function resetPosition(){panel.style.left='';panel.style.top='';panel.style.right='';panel.style.bottom='';}
function minimizePanel(){panel.hidden=true;root.classList.remove('uco-ai-open');launch.setAttribute('aria-expanded','false');launch.focus()}
function dismiss(){root.classList.remove('uco-ai-open');panel.hidden=true;launch.setAttribute('aria-expanded','false');state.closedAt=Date.now();save();launch.focus()}
launch.addEventListener('click',()=>panel.hidden?open():dismiss());minimize.addEventListener('click',minimizePanel);close.addEventListener('click',dismiss);hintDismiss.addEventListener('click',()=>{hint.hidden=true;state.invitedAt=Date.now();save()});hint.addEventListener('click',e=>{if(e.target!==hintDismiss)open()});
form.addEventListener('submit',e=>{e.preventDefault();const value=input.value.trim();if(!value)return;append('user',value);input.value='';const v=value.toLowerCase();let reply;
if(/(pedido|carrito|comprar)/.test(v))reply=area==='admin'?'Para gestionar pedidos, utiliza el panel Pedidos. El bot no puede crearlos ni modificarlos todavía.':'Para comprar, utiliza el catálogo y el carrito de la web. Próximamente podré ayudarte a preparar pedidos desde el chat.';
else if(/(pago|factura|justificante|devoluci)/.test(v))reply=area==='admin'?'Puedes consultar los justificantes y estados desde Control de pagos. No puedo realizar operaciones bancarias.':'Consulta el estado de tus pedidos y justificantes en el área de clientes. No compartas datos de tarjeta aquí.';
else if(/(producto|precio|catálogo|catalogo|buscar)/.test(v))reply='Puedes consultar los productos y precios actualizados desde el catálogo. Todavía no tengo acceso directo a su contenido.';
else reply='Gracias por tu consulta. Esta es la primera versión de ayuda guiada: todavía no dispongo de interpretación inteligente ni acceso a datos de tu cuenta. Puedes utilizar las opciones rápidas de arriba.';
append('bot',reply)});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden)minimizePanel()});
// Drag only from handle; touch on small screens keeps the sheet docked.
let dragging=null;
dragHandle.addEventListener('pointerdown',e=>{
 if(e.button!==0||matchMedia('(max-width:550px)').matches)return;
 const r=panel.getBoundingClientRect();
 dragging={id:e.pointerId,dx:e.clientX-r.left,dy:e.clientY-r.top};
 dragHandle.setPointerCapture(e.pointerId);e.preventDefault();
});
dragHandle.addEventListener('pointermove',e=>{
 if(!dragging||e.pointerId!==dragging.id)return;
 const w=panel.offsetWidth,h=panel.offsetHeight;
 const x=Math.max(8,Math.min(innerWidth-w-8,e.clientX-dragging.dx));
 const y=Math.max(8,Math.min(innerHeight-h-8,e.clientY-dragging.dy));
 Object.assign(panel.style,{left:x+'px',top:y+'px',right:'auto',bottom:'auto'});
});
const endDrag=()=>dragging=null;
dragHandle.addEventListener('pointerup',endDrag);dragHandle.addEventListener('pointercancel',endDrag);
window.addEventListener('resize',()=>{if(matchMedia('(max-width:550px)').matches)resetPosition()});

// Sugerencia no intrusiva: solo tras cierre previo, al menos 12 minutos y una vez por sesión cada 12 min.
function maybeInvite(){const t=Date.now();if(panel.hidden&&document.visibilityState==='visible'&&state.closedAt&&t-state.closedAt>=12*60*1000&&t-(state.invitedAt||0)>=12*60*1000){hint.hidden=false;state.invitedAt=t;save()}}
maybeInvite();setInterval(maybeInvite,60000)
})();
