<?php
declare(strict_types=1);
ini_set('display_errors','0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
ini_set('session.use_strict_mode','1');
ini_set('session.use_only_cookies','1');
ini_set('session.use_trans_sid','0');
session_name('UCOADMIN');
session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','samesite'=>'Strict','path'=>'/']);
session_start();
require_once dirname(__DIR__,2).'/private/session-security.php';
function out66(array $v,int $status=200):never {http_response_code($status);echo json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
if(($_SERVER['REQUEST_METHOD']??'')!=='GET')out66(['error'=>'Método no permitido'],405);
if(ucoSecurityIdleExpired())out66(['error'=>'Sesión caducada'],401);
$id=(int)($_SESSION['uco_user_id']??0);
if($id<1)out66(['error'=>'No autenticado'],401);
try {
 $db=new PDO('sqlite:'.dirname(__DIR__,2).'/private/database/catalogo.sqlite',null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
 $db->exec('PRAGMA busy_timeout=5000');
 require_once dirname(__DIR__,2).'/private/identity.php';
 require_once dirname(__DIR__,2).'/private/access-permissions.php';
 $q=$db->prepare('SELECT id,role,active,password_hash FROM admin_users WHERE id=?');$q->execute([$id]);$u=$q->fetch();
 if(!$u||(int)$u['active']!==1||!in_array($u['role'],['admin','manager'],true)||!hash_equals((string)($_SESSION['uco_auth_stamp']??''),hash('sha256',(string)$u['password_hash']))||!ucoIdentitySessionValid($db,'staff',$id,$_SESSION['uco_identity_id']??null))out66(['error'=>'Sesión no válida'],403);
 $caps=ucoOrderCapabilities($db,$id,(string)$u['role']);
 if(!ucoOrderCan($caps,'orders.view'))out66(['error'=>'No autorizado para consultar pedidos'],403);
 $table=$db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='uco_real_payments'")->fetchColumn();
 if(!$table)out66(['ok'=>true,'configured'=>false,'payments'=>[],'tasks'=>[],'counts'=>['pending'=>0,'paid'=>0,'review'=>0,'failed'=>0,'cancelled'=>0]]);
 $limit=filter_input(INPUT_GET,'limit',FILTER_VALIDATE_INT,['options'=>['default'=>100,'min_range'=>1,'max_range'=>200]]);if(!$limit)$limit=100;
 $status=(string)($_GET['status']??'all');
 if(!in_array($status,['all','pending','paid','review','failed','cancelled'],true))out66(['error'=>'Filtro inválido'],422);
 $where=$status==='all'?'':' WHERE p.state=:state';
 $sql='SELECT p.reference,p.method,p.state,p.amount_cents,p.currency,p.created_at,p.updated_at,p.order_id,o.status AS order_status,o.payment_status FROM uco_real_payments p LEFT JOIN uco_orders o ON o.id=p.order_id'.$where.' ORDER BY p.id DESC LIMIT '.(int)$limit;
 $stmt=$db->prepare($sql);if($status!=='all')$stmt->bindValue(':state',$status);$stmt->execute();$payments=$stmt->fetchAll();
 $counts=['pending'=>0,'paid'=>0,'review'=>0,'failed'=>0,'cancelled'=>0];foreach($db->query('SELECT state,COUNT(*) AS n FROM uco_real_payments GROUP BY state') as $r){if(array_key_exists($r['state'],$counts))$counts[$r['state']]=(int)$r['n'];}
 $tasks=[];
 if($db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='uco_payment_review_tasks'")->fetchColumn()){
  $tasks=$db->query("SELECT t.id,t.reference,t.kind,t.status,t.note,t.evidence_ref,t.actor,t.created_at,p.method,p.state AS payment_state FROM uco_payment_review_tasks t LEFT JOIN uco_real_payments p ON p.reference=t.reference WHERE t.status='open' ORDER BY t.id DESC LIMIT 100")->fetchAll();
 }
 out66(['ok'=>true,'configured'=>true,'payments'=>$payments,'tasks'=>$tasks,'counts'=>$counts]);
} catch(Throwable $e){error_log('UCO payment-admin-66: '.$e->getMessage());out66(['error'=>'No se pudo consultar el registro de pagos'],500);}
