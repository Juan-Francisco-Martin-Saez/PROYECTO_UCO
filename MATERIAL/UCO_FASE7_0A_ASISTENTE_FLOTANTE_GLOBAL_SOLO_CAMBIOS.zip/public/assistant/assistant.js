/* Fase 7.0 — widget global de ayuda guiada, sin conexión a IA ni operaciones bancarias. */
(()=>{'use strict';
if(document.getElementById('uco-assistant-root'))return;
const area=document.currentScript?.dataset.area||'public';
const store='uco_assistant_v70';const MAX=24;const now=Date.now();
let state={messages:[],closedAt:0,invitedAt:0};
try{const x=JSON.parse(sessionStorage.getItem(store)||'{}');if(x&&typeof x==='object'){state={...state,...x};if(!Array.isArray(state.messages))state.messages=[];}}catch{}
const save=()=>{try{sessionStorage.setItem(store,JSON.stringify({...state,messages:state.messages.slice(-MAX)}))}catch{}};
const root=document.createElement('div');root.id='uco-assistant-root';root.setAttribute('data-area',area);
const launch=document.createElement('button');launch.type='button';launch.className='uco-ai-launch';launch.setAttribute('aria-expanded','false');launch.setAttribute('aria-controls','uco-ai-panel');launch.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 3v3m-6 6H3m18 0h-3M7 8h10a3 3 0 0 1 3 3v5a3 3 0 0 1-3 3H4v-8a3 3 0 0 1 3-3Z"/><path d="M8 13h.01M16 13h.01M9 16c2 1 4 1 6 0"/></svg><span>Asistente UCO</span>';
const panel=document.createElement('section');panel.id='uco-ai-panel';panel.className='uco-ai-panel';panel.hidden=true;panel.setAttribute('aria-label','Asistente UCO');
const head=document.createElement('div');head.className='uco-ai-head';const heading=document.createElement('strong');heading.textContent=area==='admin'?'Ayuda administrativa':area==='client'?'Asistente de clientes':'Asistente UCO';const close=document.createElement('button');close.type='button';close.className='uco-ai-close';close.textContent='Cerrar ×';head.append(heading,close);
const messages=document.createElement('div');messages.className='uco-ai-messages';messages.setAttribute('role','log');messages.setAttribute('aria-live','polite');
const actions=document.createElement('div');actions.className='uco-ai-actions';
const form=document.createElement('form');form.className='uco-ai-form';const input=document.createElement('input');input.type='text';input.maxLength=300;input.placeholder='Escribe tu consulta…';input.setAttribute('aria-label','Consulta al asistente');input.autocomplete='off';const send=document.createElement('button');send.type='submit';send.textContent='Enviar';form.append(input,send);
const foot=document.createElement('div');foot.className='uco-ai-foot';foot.textContent='Versión inicial: ayuda guiada. No procesa pedidos ni pagos.';
panel.append(head,messages,actions,form,foot);
const hint=document.createElement('div');hint.className='uco-ai-hint';hint.hidden=true;const hintText=document.createElement('span');hintText.textContent='¿Necesitas ayuda? Estoy aquí cuando quieras.';const hintDismiss=document.createElement('button');hintDismiss.type='button';hintDismiss.textContent='×';hintDismiss.setAttribute('aria-label','Descartar sugerencia');hint.append(hintText,hintDismiss);root.append(panel,hint,launch);document.body.append(root);
const greeting=area==='admin'?'Puedo orientarte por las secciones de administración. No realizo cambios por ti.':area==='client'?'Puedo ayudarte a localizar productos y explicarte cómo preparar tu pedido.':'Puedo ayudarte a encontrar productos y orientarte sobre cómo comprar en UCO.';
function append(who,text,persist=true){const item=document.createElement('div');item.className='uco-ai-msg';item.dataset.who=who;item.textContent=text;messages.append(item);messages.scrollTop=messages.scrollHeight;if(persist){state.messages.push({who,text});state.messages=state.messages.slice(-MAX);save()}}
if(state.messages.length){state.messages.slice(-MAX).forEach(m=>{if((m.who==='user'||m.who==='bot')&&typeof m.text==='string')append(m.who,m.text,false)})}else append('bot',greeting);
const shortcuts=area==='admin'?[['Pedidos','Para revisar pedidos, entra en la sección Pedidos. Esta versión no puede modificarlos.'],['Clientes','Gestiona los clientes desde su sección administrativa.'],['Pagos','Consulta Control de pagos para revisar estados. El asistente no puede ejecutar cobros.']]:[['Catálogo','Puedes explorar el catálogo y utilizar sus filtros para localizar productos.'],['Mi pedido','Revisa el carrito y confirma los datos en el proceso normal de compra.'],['Ayuda','Cuéntame qué necesitas. En esta primera versión puedo orientarte, pero aún no interpreto pedidos automáticamente.']];
shortcuts.forEach(([label,answer])=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.addEventListener('click',()=>{append('user',label);append('bot',answer)});actions.append(b)});
function open(){panel.hidden=false;hint.hidden=true;launch.setAttribute('aria-expanded','true');input.focus()}
function dismiss(){panel.hidden=true;launch.setAttribute('aria-expanded','false');state.closedAt=Date.now();save();launch.focus()}
launch.addEventListener('click',()=>panel.hidden?open():dismiss());close.addEventListener('click',dismiss);hintDismiss.addEventListener('click',()=>{hint.hidden=true;state.invitedAt=Date.now();save()});hint.addEventListener('click',e=>{if(e.target!==hintDismiss)open()});
form.addEventListener('submit',e=>{e.preventDefault();const value=input.value.trim();if(!value)return;append('user',value);input.value='';const v=value.toLowerCase();let reply;
if(/(pedido|carrito|comprar)/.test(v))reply=area==='admin'?'Para gestionar pedidos, utiliza el panel Pedidos. El bot no puede crearlos ni modificarlos todavía.':'Para comprar, utiliza el catálogo y el carrito de la web. Próximamente podré ayudarte a preparar pedidos desde el chat.';
else if(/(pago|factura|justificante|devoluci)/.test(v))reply=area==='admin'?'Puedes consultar los justificantes y estados desde Control de pagos. No puedo realizar operaciones bancarias.':'Consulta el estado de tus pedidos y justificantes en el área de clientes. No compartas datos de tarjeta aquí.';
else if(/(producto|precio|catálogo|catalogo|buscar)/.test(v))reply='Puedes consultar los productos y precios actualizados desde el catálogo. Todavía no tengo acceso directo a su contenido.';
else reply='Gracias por tu consulta. Esta es la primera versión de ayuda guiada: todavía no dispongo de interpretación inteligente ni acceso a datos de tu cuenta. Puedes utilizar las opciones rápidas de arriba.';
append('bot',reply)});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden)dismiss()});
// Sugerencia no intrusiva: solo tras cierre previo, al menos 12 minutos y una vez por sesión cada 12 min.
function maybeInvite(){const t=Date.now();if(panel.hidden&&document.visibilityState==='visible'&&state.closedAt&&t-state.closedAt>=12*60*1000&&t-(state.invitedAt||0)>=12*60*1000){hint.hidden=false;state.invitedAt=t;save()}}
maybeInvite();setInterval(maybeInvite,60000)
})();
