# UCO 7.2E.27 — Limitación de solicitudes OpenAI

Se añade un limitador de 10 solicitudes por 60 segundos por `REMOTE_ADDR` en `private/assistant/openai-rate-limit-72e27.php`, aplicado en `public/api/assistant-openai.php` antes de llamar a OpenAI. Se ignoran cabeceras IP aportadas por clientes. Se usan archivos de estado privados, hash SHA-256 de IP, permisos restrictivos y bloqueo exclusivo `flock`. Fallos de almacenamiento bloquean la solicitud (429). No se modifica el prompt, la clave, el buscador comercial, pedidos, pagos, bases de datos ni el frontend.

## Pruebas
- PHP CLI: 13/13 controles de limitación superados.
- Sintaxis PHP: correcta para los tres archivos revisados.
- Hashes de SQLite, configuración OpenAI y JavaScript: idénticos a 7.2E.26.

## Pendiente
- Pruebas HTTP reales y concurrencia de carga en servidor.
- Validar permisos de escritura de `private/logs` en IONOS.
- Evaluar usuarios tras IP compartida/NAT; no hay todavía cuotas por usuario ni limpieza periódica de archivos de estado.
- El límite es una barrera básica, no un sistema completo de control de abuso.
