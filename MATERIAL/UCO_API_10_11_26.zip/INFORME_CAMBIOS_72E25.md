# UCO 7.2E.25 — Guardia uniforme en fallback de OpenAI

Se detectó que `askUcoLogic` llamaba a OpenAI cuando no había resultados y `contextualRoute(question)==='general'`. Esa condición era menos restrictiva que el enrutamiento principal y podía transferir preguntas no destinadas a OpenAI.

Se sustituye **solo** esa condición por `shouldUseGeneralEngine72e22(question)`. No se cambian los endpoints, el prompt, las bases de datos ni el flujo de pedidos, precios o carrito.

Se añaden 16 comprobaciones de clasificación y de las dos rutas; pruebas de navegador/HTTP siguen pendientes.
