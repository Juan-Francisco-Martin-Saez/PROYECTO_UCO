# UCO 7.2E.39 — Auditoría de privacidad en derivaciones OpenAI

## Hallazgo y corrección
El prefijo manual `IA:` evitaba la clasificación automática y permitía enviar contenido comercial o identificable a la API. Se añade filtrado conservador en el frontend y **validación independiente en PHP**, antes del limitador y de cualquier petición a OpenAI. El servidor devuelve HTTP 422 para mensajes no aptos. Se rechazan direcciones de correo, teléfonos españoles, referencias comerciales, términos de pedidos, clientes, pagos, facturas, carrito, contraseñas y datos bancarios.

## Verificación local
- 28/28 casos de privacidad JavaScript.
- Guardia PHP y orden previo a OpenAI comprobados estáticamente.
- Sintaxis PHP y JS correctas.
- Baterías históricas 7.2E.33–38 superadas.

## Limitaciones
No se ha ejecutado un test HTTP de extremo a extremo del filtro PHP: el PHP local carece de `mbstring` y `curl`. Las expresiones regulares no son un detector universal de datos personales: no garantizan bloquear nombres propios, direcciones redactadas de forma libre, números internacionales ni datos sensibles inusuales. La ruta `IA:` no evita la nueva validación. Validación real en IONOS pendiente al final.

## Archivos de producción modificados
- `public/assistant/assistant.js`: filtro previo a toda derivación, incluida `IA:`.
- `public/api/assistant-openai.php`: filtro en servidor antes de la llamada externa.

No se han modificado el prompt, la configuración de claves, las bases de datos, precios, pedidos ni pagos.
