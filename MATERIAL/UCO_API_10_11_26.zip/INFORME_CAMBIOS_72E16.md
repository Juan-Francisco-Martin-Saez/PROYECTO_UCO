# UCO 7.2E.16 — Auditoría de búsquedas complejas

Se incorpora `tests/test-search-ambiguity-72e16.py`, que consulta el catálogo SQLite en modo de solo lectura y genera `INFORME_RESULTADOS_72E16.json`.

## Hallazgos
- «Aros de cebolla» recupera las referencias específicas, pero también puede encontrar preparados con cebolla por sus descripciones.
- «Cebolla congelada» no equivale necesariamente a «aros de cebolla»: hace falta validar el tipo de producto y no solo la coincidencia léxica.
- «Verduras con cebolla» es una consulta potencialmente ambigua entre producto compuesto e ingrediente.
- «Zanahoria» puede mostrar mezclas que incluyen zanahoria; conviene distinguir producto principal de ingrediente.

**Alcance:** diagnóstico de 5 consultas con aproximación SQL. No es una prueba del endpoint PHP ni certifica la relevancia semántica. No se modifica ningún PHP, SQLite, precio, pedido, carrito ni prompt. Siguiente paso propuesto: reglas explícitas de calificadores y prueba funcional HTTP en entorno compatible.
