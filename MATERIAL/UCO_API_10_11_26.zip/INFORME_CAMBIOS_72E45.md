# UCO 7.2E.45 — Continuidad del chatbot tras fallos de OpenAI

- Se ejecuta el manejador real de envío (`submit`) del chatbot con servicios externos simulados.
- 35 comprobaciones sobre errores de OpenAI, continuidad del catálogo y pedidos, recuperación, estados protegidos, prefijo IA y reinicio.
- No se realizaron llamadas externas ni pruebas en IONOS.
- El enrutador y las funciones comerciales son dobles de prueba: no constituye una prueba integral de producción.
- Sin modificaciones en archivos de producción, prompt, pedidos, pagos ni bases de datos.
