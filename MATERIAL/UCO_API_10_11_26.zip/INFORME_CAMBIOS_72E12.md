# UCO — 7.2E.12 — Plurales, singulares y sinónimos seguros

Se ajusta exclusivamente `public/api/assistant-catalog-71a.php`.

- Normaliza los términos aprobados a su concepto canónico también cuando el usuario escribe un plural.
- Evita expandir indiscriminadamente los alias: `papas` se resuelve a `patata` y no se busca como `%papa%`, que podría devolver `PAPAYA`.
- Mantiene los filtros AND entre atributos, la referencia exacta, pesos, envases, formato y ordenación existentes.
- Si dos conceptos tienen la misma raíz, evita asignarla arbitrariamente.
- No cambia ninguna base de datos ni el esquema JSON de la API.

## Verificación
- Sintaxis PHP: comprobada con `php -l`.
- Pruebas de datos SQLite de solo lectura: `patat` coincide con productos de patata; el fragmento `papa` también aparece en `PAPAYA`, que motivó la corrección.
- Ejecución HTTP con pdo_sqlite y mbstring: pendiente en servidor compatible.
