# UCO 7.2E.31 — Preparación de validación en IONOS

Se añaden `tests/preflight-ionos-72e31.php` y `GUIA_DESPLIEGUE_IONOS_72E31.md`. Ningún archivo de producción se modifica.

## Resultados locales
- Sintaxis del preflight: correcta.
- Preflight CLI: **8/10**, con `mbstring` y `curl` ausentes en el entorno local.
- Los seis archivos críticos comparados con 7.2E.30 son idénticos.
- No se ha ejecutado ni desplegado nada en IONOS.
- No se ha probado una llamada real a OpenAI.

El preflight no realiza llamadas de red, no lee ni imprime claves, no crea directorios y no modifica bases de datos.
