# UCO Sa Pobla 2.0 — Fase 7.2E.56

## Objetivo
Auditar conversaciones largas con cambios de contexto entre motor general, catálogo y estados de pedido, presupuesto, transferencia y carrito.

## Pruebas nuevas
`node tests/test-long-context-72e56.cjs`: 902/902 verificaciones: 20 sesiones simuladas de 40 turnos, 400 cambios de contexto, 100 derivaciones automáticas generales, 720 retenciones locales o por contexto, 80 bloqueos de privacidad y 2 casos de contexto de catálogo caducado o inválido.

## Regresiones
Privacidad JS 28/28 y 7/7; enrutamiento real 42/42; 192 interacciones de continuidad del controlador con servicios simulados. Sintaxis JS y PHP correcta.

## Hallazgo para revisión
Con pedido activo, ciertas consultas con palabras de catálogo pueden priorizarse como seguimiento de pedido. Este comportamiento está en las reglas actuales y requiere evaluar la intención del usuario antes de modificarlo. La auditoría no comprueba la corrección semántica de respuestas comerciales ni realiza una prueba real de navegador.

## Límites
No hay cambios en código de producción, prompt, precios, base de datos, pagos ni pedidos. No se ha accedido a IONOS ni se ha llamado a OpenAI. Las pruebas de rutas usan funciones reales y estados simulados; no equivalen a pruebas completas de interfaz o transacciones reales.
