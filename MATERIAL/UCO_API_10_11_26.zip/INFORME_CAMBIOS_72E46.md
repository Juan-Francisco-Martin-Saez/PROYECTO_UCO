# UCO 7.2E.46 — Integración real del enrutamiento

Se ejecutan nueve funciones reales de `public/assistant/assistant.js` en VM Node.js: normalización, lectura del contexto de catálogo, seguimiento, ID de pedido, clasificación de pedido, documentos propios, enrutamiento contextual, privacidad y selección automática de OpenAI. El almacenamiento de sesión se simula; no se realizan peticiones HTTP ni operaciones de pedidos.

- Prueba nueva: 42/42.
- Regresiones: 18/18, 25/25, 32/32, 4000/4000, 28/28, 7/7, 23/23, 11/11.
- Sintaxis JavaScript correcta. SHA256 de assistant.js idéntico a 7.2E.45: `8eba16801110172e4dac4c13d9465d6daaa7d0654d8f6936612cd9266e55b81c`.
- Sin cambios de producción, prompt, pagos, pedidos ni bases de datos.

Observación: algunas preguntas que incluyen DNI, IBAN o teléfonos pueden satisfacer `shouldUseGeneralEngine72e22`, pero `isSafeGeneralQuestion72e39` bloquea su envío. Los dos filtros son necesarios; no debe considerarse el enrutador inicial una barrera de privacidad suficiente.

Pendiente: pruebas integrales en navegador, IONOS y OpenAI real, aplazadas por petición del usuario.
