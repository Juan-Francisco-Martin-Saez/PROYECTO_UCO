# UCO 7.2E.41 — Validación HTTP local

- 8/8 solicitudes HTTP de prueba con resultado esperado: GET 405, Content-Type 415, JSON inválido 422, mensajes comerciales/identificadores 422 y consulta general sin conexión externa 503.
- Se ha utilizado un shim local de `mbstring` para ejecutar PHP; **no equivale a validar la extensión nativa**. El shim solo es auxiliar de pruebas y no debe desplegarse como sustituto.
- Sin llamadas a OpenAI ni acceso a IONOS.
- No se ha modificado código de producción.
- La prueba general llega a configuración y devuelve 503, sin demostrar respuesta de OpenAI.
- Las pruebas HTTP no demuestran cobertura exhaustiva de privacidad.
