# UCO 7.2E.33 — Matriz de conversaciones y evaluación del enrutamiento

Se añade `tests/test-dialogos-prompt-72e33.cjs`, que ejecuta las funciones reales de normalización, clasificación y derivación automática extraídas del frontend, con estados de conversación simulados. Incluye preguntas generales, comerciales, pedidos, contextos activos, carrito y reinicio.

## Resultado
32/32 casos de enrutamiento con funciones reales extraídas del JS. Sin llamadas a OpenAI.

## Hallazgos y límites
- Una pregunta general no se deriva automáticamente a OpenAI mientras exista contexto de catálogo, pedido, presupuesto o carrito. Es una restricción conservadora actual, no una capacidad de cambio de tema fluido.
- Las pruebas comprueban **enrutamiento**, no calidad factual del texto generado por OpenAI, ni el contenido del prompt remoto, ni HTTP real.
- El prefijo explícito `IA:` es una vía separada que no se evalúa en esta matriz; no se debe utilizar para transferir datos comerciales privados.
- La validación en IONOS permanece pospuesta hasta el final por indicación del propietario.

Sin modificaciones de código de producción, prompt, bases de datos, precios, pedidos o pagos.
