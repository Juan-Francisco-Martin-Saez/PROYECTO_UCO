# UCO 7.2E.17 — Auditoría de calificadores comerciales

Esta fase registra evidencia de términos comerciales en nombres y metadatos del catálogo real. No modifica el algoritmo PHP ni introduce exclusiones no verificadas. Un término solo en la descripción no debe asumirse como presentación principal del producto. Se conservan intactas la base de datos, los precios, el carrito, los pedidos y el prompt de OpenAI.

## Archivos añadidos
- `tests/test-qualifiers-72e17.py`: prueba SQLite de solo lectura.
- `INFORME_CALIFICADORES_72E17.json`: resultados de seis consultas y evidencia de coincidencia por campo.

## Pendiente
Validación funcional HTTP con PHP pdo_sqlite/mbstring y criterios de aceptación de relevancia antes de modificar el ranking.
