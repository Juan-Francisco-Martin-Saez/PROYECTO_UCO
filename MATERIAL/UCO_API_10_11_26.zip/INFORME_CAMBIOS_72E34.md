# UCO 7.2E.34 — Cambio de contexto comercial a general

Se elimina exclusivamente el veto automático a consultas generales cuando existe un contexto de búsqueda de catálogo previo. La función `shouldUseGeneralEngine72e22` conserva las barreras para preguntas de seguimiento, pedidos activos, presupuestos, transferencias y referencias de carrito, y mantiene el filtro de términos comerciales. No se borra el contexto de catálogo al hacer una pregunta general, por lo que se puede retomar la búsqueda.

Se añaden 18 casos de prueba y se actualizan dos expectativas antiguas de los tests 7.2E.22 y 7.2E.23 al comportamiento expresamente solicitado. Verificados 18/18 + 22/22 + 13/13 y `node --check` correcto. Las pruebas no incluyen navegador ni HTTP real. La detección se basa en reglas conservadoras y no comprende todas las formas de expresarse; mantener revisión humana de casos límite.

No se alteran el prompt, las API PHP, los pedidos, pagos ni las bases de datos. La validación real en IONOS permanece aplazada hasta el final.
