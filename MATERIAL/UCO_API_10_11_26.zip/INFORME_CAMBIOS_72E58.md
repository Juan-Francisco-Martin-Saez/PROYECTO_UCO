# UCO 7.2E.58 — Auditoría de ambigüedades y seguimientos
Fecha: 10/11/2026.

## Alcance
32 casos dirigidos ejecutados sobre `contextualRoute`, `orderQuestion` e `isOwnDocumentQuery` reales, mediante Node VM. No se ha alterado el código de producción.

## Resultado
31/32 superados. Fallo reproducible: con `lastOwnOrderId=44`, «¿Y ese pedido?» devuelve `general` en vez de `order`.

## Riesgo y propuesta
La corrección requiere coherencia entre `orderQuestion`, `contextualRoute` y `askOwnOrders`. Cambiar solo el router podría mostrar varios pedidos en lugar de seguir el pedido activo. Debe añadirse una regla limitada a referencias elípticas inequívocas con pedido activo y una prueba de resolución del ID, antes de incorporar cambios en producción.

## Limitaciones
Las pruebas son locales y de clasificación. No verifican datos reales de pedidos, carrito ni respuestas de OpenAI. IONOS y llamadas reales a OpenAI pendientes de validación final.
