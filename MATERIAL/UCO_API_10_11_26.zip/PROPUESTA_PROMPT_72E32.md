# Propuesta de refinamiento del prompt — sin aplicar

## Contrato actual observado
El endpoint envía únicamente `input` (la pregunta), referencia al prompt publicado en versión 2 y herramienta `file_search`. Exige que el texto generado sea JSON con `response` de tipo cadena. Rechaza importes monetarios y marca toda respuesta `commercial_verified: false`. El frontend decide previamente si la consulta va al motor general.

## Propuesta para aprobación posterior
1. Devolver siempre un objeto JSON con `response` (texto), `status` (estado) y, si es útil, `source_note` (indicación breve de procedencia).
2. Ante preguntas generales: contestar con claridad, sin inventar fuentes documentales ni precios.
3. Ante precios, referencias, stock, pedidos, facturas, pagos o datos de clientes: no dar resultados comerciales; remitir al motor UCO autenticado.
4. Si no hay información suficiente, indicar la incertidumbre o pedir una aclaración concreta.
5. Nunca afirmar que se ha efectuado una operación (pedido, pago, cambio de cuenta) desde el prompt general.
6. Respetar el máximo actual de 1800 caracteres para `response`; evitar números monetarios en el texto generado.

## Casos de aceptación para validar más adelante con OpenAI real
- «¿Qué es la congelación rápida?» → explicación general, sin precios.
- «¿Qué significa IV gama?» → definición general, sin afirmar stock UCO.
- «¿Cuánto cuesta la patata?» → resolver exclusivamente con catálogo comercial.
- «Añade 3 cajas de croquetas» → no ejecutar desde el prompt general.
- «¿Dónde está mi pedido?» → acceso comercial autenticado, no OpenAI general.
- «¿Qué diferencia hay entre congelado y ultracongelado?» → respuesta informativa general.
- «Dime la referencia y el precio del producto X» → no inventar datos comerciales.
- «¿Qué es una API?» → respuesta general.
- «¿Puedes confirmar que ya he pagado?» → no confirmar transacciones.
- «No encuentro el producto Y» → mantener búsqueda UCO; no consultar OpenAI como sustituto.

**No es una prueba del contenido del prompt remoto**: no se ha consultado ni editado el prompt publicado. Esta propuesta requiere autorización expresa antes de aplicarse.
