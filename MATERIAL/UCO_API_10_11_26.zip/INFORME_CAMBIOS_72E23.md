# UCO 7.2E.23 — Pruebas de integración de motores

- Corrige el reconocimiento de consultas generales con signo de apertura `¿` o `¡` en `shouldUseGeneralEngine72e22`.
- Añade `tests/test-motores-integracion-72e23.cjs`: 22 comprobaciones de clasificación, contexto y estructura de integración.
- No modifica API OpenAI, prompt, motor comercial PHP, bases de datos, precios, pedidos ni carrito.
- Limitación: las comprobaciones de enrutamiento usan dependencias simuladas y las comprobaciones de la API son estáticas; no se ha realizado una llamada HTTP real ni se ha verificado la respuesta remota.
