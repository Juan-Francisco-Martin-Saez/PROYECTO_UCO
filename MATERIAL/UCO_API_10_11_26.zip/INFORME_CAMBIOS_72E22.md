# UCO 7.2E.22 — Enrutamiento automático conservador

- Se modifica exclusivamente `public/assistant/assistant.js` para derivar preguntas generales inequívocas a la API OpenAI existente (`/api/assistant-openai.php`) sin prefijo `IA:`.
- Se mantienen las consultas de catálogo, pedidos, carrito y documentos en su flujo local; si existe contexto comercial no se deriva a OpenAI.
- Las preguntas ambiguas siguen en el flujo anterior. El prefijo `IA:` sigue disponible y no se cambia el prompt.
- Si la API OpenAI falla, se comunica la indisponibilidad sin inventar respuestas.
- Se incorpora `tests/test-auto-route-72e22.cjs` para comprobar escenarios de derivación y salvaguardas.

## Verificación

- `node --check public/assistant/assistant.js`: OK.
- `node tests/test-auto-route-72e22.cjs`: OK (13 comprobaciones).
- No se modifica PHP, las bases SQLite, pedidos, precios ni pagos.
- No se ejecutaron pruebas HTTP reales, de extremo a extremo ni con la API de OpenAI. No está certificado para producción.

## Limitación

El enrutamiento es deliberadamente conservador y basado en expresiones. No cubre todas las preguntas generales; los casos ambiguos mantienen el comportamiento previo.
