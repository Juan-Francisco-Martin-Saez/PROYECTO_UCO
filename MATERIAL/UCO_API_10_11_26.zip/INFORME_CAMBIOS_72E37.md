# UCO 7.2E.37 — Conciliación de regresiones

Se actualizan exclusivamente las expectativas históricas de 7.2E.24, 7.2E.25 y 7.2E.33 sobre preguntas generales explícitas con contexto de catálogo. Se conserva el bloqueo de pedidos, presupuestos, transferencias, carrito y seguimientos elípticos.

## Pruebas locales
- test-dialogos-prompt-72e33.cjs: OK — 32/32 casos de enrutamiento con funciones reales extraídas del JS. Sin llamadas a OpenAI.
- test-mixed-dialogues-72e36.cjs: OK — {"passed":32,"total":32,"sessions":7,"status":"OK"}
- test-context-switch-72e34.cjs: OK — 18/18 pruebas de cambio de contexto superadas
- test-context-switch-72e35.cjs: OK — 25/25 pruebas de cambio de contexto superadas
- test-auto-route-72e22.cjs: OK — 13/13 validaciones de enrutamiento (11 escenarios + 2 verificaciones de integración) OK
- test-motores-integracion-72e23.cjs: OK — 22/22 comprobaciones de integración estática y clasificación superadas (sin HTTP)
- test-conversaciones-72e24.cjs: OK — 16/16 escenarios y guardas estáticas correctos; sin HTTP ni simulación DOM completa
- test-fallback-72e25.cjs: OK — 16/16 comprobaciones de rutas y guardas correctas; no son pruebas HTTP

No se modificó código de producción ni prompt, base de datos, pagos o precios. No se ha comprobado IONOS ni una respuesta real de OpenAI.
