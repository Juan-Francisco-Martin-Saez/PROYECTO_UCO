# UCO 7.2E.51 — Auditoría contextual ampliada

- Casos contextuales: 35; cumplen expectativas 19; discrepancias 16.
- Guardas estructurales: 3/3. Total: 22/38.
- Discrepancias: wav variación, messier variación, formato pdf, formato json, formato mp3, catalogo estelar, catalogo astronomia, referencia bibliografica, precio economico, oferta demanda, producto matematico, stock fotografia, cuenta matematica, cliente servidor, token programacion, api key tecnica.
- Son expectativas educativas de auditoría; no se han relajado filtros.
- Regresiones: privacidad JS 28/28 y 7/7; enrutamiento 42/42.
- Producción, prompt, pedidos, pagos y BD sin cambios. Sin IONOS ni OpenAI real.
