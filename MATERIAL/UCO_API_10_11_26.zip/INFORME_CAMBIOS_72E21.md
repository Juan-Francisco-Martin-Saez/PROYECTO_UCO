# UCO 7.2E.21 — Preparación de separación de motores

La web existente ya dispone de `public/api/assistant-openai.php`, `public/api/assistant-catalog-71a.php` y `contextualRoute` en `public/assistant/assistant.js`. La llamada a OpenAI está actualmente disponible mediante el prefijo `IA:`. **No se ha alterado ese comportamiento**.

Se añade una propuesta de clasificación independiente `private/assistant/query-router-72e21.php` y su prueba `tests/test-query-router-72e21.php`. Las rutas propuestas son `commercial`, `authenticated`, `general` y `clarify`. Este clasificador usa reglas simples y no es todavía suficiente para decidir automáticamente todos los casos ambiguos; debe someterse a pruebas y reglas de contexto antes de conectarlo al frontend.

No se modifica el prompt hospedado, ni `assistant-openai.php`, ni el JavaScript público, ni las API de pedidos, carrito, pagos o precios. Las bases SQLite se conservan sin alteraciones. No se realizan llamadas reales a OpenAI ni pruebas HTTP.
