# UCO 7.2E.20 — Corrección de regresiones en pruebas

Se corrigen **dos pruebas antiguas**, no el algoritmo de producción:

1. `test-relevancia-72e13.py`: antes marcaba erróneamente como falso positivo un producto compuesto si incluía otro ingrediente (por ejemplo, tempura con zanahoria y cebolla). Ahora distingue presencia del término y evita ese supuesto incorrecto. **No certifica el orden de relevancia ni la intención semántica**.
2. `test-assistant-compound-72e15.py`: la comprobación de texto estaba desactualizada desde que se añadió la prioridad de frase (nivel 5) antes de la coincidencia de todas las palabras (nivel 6). Se comprueba el orden vigente sin modificar PHP.

Se conserva íntegramente la base de datos, PHP comercial, precios, carrito, pedidos y prompt. HTTP no se ejecuta sin las extensiones necesarias.
