# UCO 7.2E.29 — Verificación HTTP de errores 429 y 503

**Producción sin cambios.** Se incorpora `tests/test-http-429-503-72e29.py` y el shim exclusivo de pruebas `tests/php-mbstring-shim-72e29.php`.

Resultados HTTP local: 14/14 correctos. Diez POST válidos devuelven 503 porque no existe cURL disponible; el undécimo devuelve 429 con Retry-After 60. GET devuelve 405; Content-Type incorrecto 415; cuerpo mayor de 12 KB 413.

**Limitaciones:** no se han probado respuestas reales de OpenAI, no hay despliegue IONOS, no se ha probado la concurrencia de carga ni la expiración de 60 segundos. El shim no debe instalarse en producción. El script limpia los archivos de rate limit de su copia local de pruebas; no ejecutarlo sobre un servidor en uso.

Hashes de código de producción, configuración, SQLite y JS idénticos a 7.2E.28.
