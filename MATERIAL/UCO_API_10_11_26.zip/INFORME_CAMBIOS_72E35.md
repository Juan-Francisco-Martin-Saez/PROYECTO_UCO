# UCO 7.2E.35 — Interpretación de seguimientos
- Cambio único de producción: `public/assistant/assistant.js`.
- Las preguntas generales explícitas precedidas por «y», «ahora», «por cierto», «otra cosa» o «cambiando de tema» pueden derivarse a OpenAI aunque exista contexto de catálogo.
- Seguimientos elípticos, consultas comerciales y estados de pedido, presupuesto o carrito permanecen locales.
- 25/25 pruebas nuevas y 18/18 pruebas anteriores superadas localmente.
- Sin modificación del prompt, API, bases de datos, precios ni pagos.
- Pruebas reales de IONOS aplazadas por petición del usuario.
