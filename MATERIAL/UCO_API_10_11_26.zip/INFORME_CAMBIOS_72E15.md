# UCO 7.2E.15 — Relevancia de consultas compuestas

Se añade una prioridad SQL para productos cuyos nombres oficiales contienen **todos** los calificadores de la consulta, incluso cuando no están contiguos. Se mantienen las prioridades superiores de nombre exacto, prefijo y frase, los filtros AND, referencias, pesos, formatos y sinónimos. Las coincidencias basadas en descripciones siguen siendo posibles, pero se ordenan detrás.

No se alteran las bases de datos ni el prompt. Esta es una mejora de ordenación, no una clasificación semántica de ingredientes ni una prueba HTTP en producción.
