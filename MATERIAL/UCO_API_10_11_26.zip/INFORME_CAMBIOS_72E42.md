# UCO 7.2E.42 — Seguridad HTTP ampliada

- **25/25** solicitudes HTTP locales con respuesta esperada: 405, 415, 422, 413, 503 y 429.
- Se verifica límite de 10 solicitudes/minuto/IP en el servidor PHP local, y 429 en la undécima.
- Se verifica que las consultas sensibles se rechazan con 422 incluso tras agotar el límite.
- Se usa un shim `mbstring` **solo en el entorno de prueba**, por ausencia de extensión nativa; no se despliega.
- Sin clave OpenAI y sin llamadas externas; 503 en consultas generales permitidas por falta de configuración.
- No se modificó código de producción, prompts, precios, pedidos, pagos ni base de datos.
- La prueba no demuestra exhaustividad de detección de datos personales, ni funcionamiento en IONOS.

## Archivos nuevos
- `tests/test-http-security-72e42.py`
- `tests/RESULTADOS_HTTP_72E42.json`
- `INFORME_CAMBIOS_72E42.md`
