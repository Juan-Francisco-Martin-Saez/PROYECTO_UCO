# UCO 7.2E.24 — Conversaciones consecutivas y contexto

Pruebas de secuencias general → catálogo → general, guardas para contexto de catálogo, pedido, presupuesto, transferencia, carrito y seguimiento. Se verifica que el prefijo IA: mantiene prioridad, que hay salida temprana y que se libera el estado busy. **No se modifica código de producción** ni prompt, precios o bases de datos. No se certifica interacción real en navegador ni HTTP.
