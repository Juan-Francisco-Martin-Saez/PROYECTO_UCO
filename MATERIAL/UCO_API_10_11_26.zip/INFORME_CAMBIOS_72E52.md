# UCO 7.2E.52 — Clasificación contextual segura

Lista cerrada de 18 preguntas didácticas; los identificadores estructurados se comprueban antes de la excepción. No hay clasificación semántica general ni relajación de términos comerciales. Sin llamadas externas.
