# UCO 7.2E.50 — Excepciones contextuales limitadas

- Corregidos dos falsos positivos: «¿Qué es el formato WAV en audio?» y «¿Qué es el catálogo de Messier en astronomía?».
- La excepción requiere coincidencia exacta normalizada; variantes comerciales siguen rechazadas.
- Filtro JS y PHP actualizados; sin cambios en carrito, pedidos, pagos, base de datos ni prompt.
- Test local cruzado: 30/30. No se realizaron llamadas reales a OpenAI ni IONOS.
- Pendiente: verificación real final y revisión de variantes lingüísticas y Unicode no cubiertas.
