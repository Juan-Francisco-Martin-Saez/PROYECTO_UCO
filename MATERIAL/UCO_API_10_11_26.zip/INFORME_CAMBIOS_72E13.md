# Fase 7.2E.13 — Relevancia y falsos positivos (10/11/2026)

Base: versión 7.2E.12.

Esta entrega incorpora pruebas automáticas de solo lectura sobre el catálogo SQLite real. No modifica código de producción, bases de datos, precios ni pedidos.

Resultado de la prueba léxica independiente: **INCIDENCIAS**. Se han ejecutado 5 escenarios.

La prueba aproxima coincidencias SQL por raíces y NO ejecuta el endpoint PHP ni valida por completo el algoritmo de sinónimos, ranking o el JSON de respuesta. Las pruebas HTTP siguen pendientes en un entorno con pdo_sqlite y mbstring.

Ejecutar desde la raíz del proyecto: `python tests/test-relevancia-72e13.py`. Los resultados están en `tests/RESULTADOS_RELEVANCIA_72E13.json`.
