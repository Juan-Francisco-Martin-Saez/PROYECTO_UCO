# UCO 7.2E.40 — Refuerzo de privacidad y HTTP local

Se añadieron detecciones conservadoras de DNI/NIE, IBAN español y formatos de claves (`sk-`, `ghp_`) en JS y PHP. No se modificaron prompt, pedidos, precios, pagos ni base de datos.

## Verificación
- Pruebas JS de privacidad heredadas: 28/28 correctas.
- Sintaxis PHP: correcta.
- HTTP local: GET 405 y POST text/plain 415 correctos.
- POST JSON `{}`: devuelve 422 por consulta inválida. Una consulta JSON válida no se ha podido verificar de extremo a extremo debido a la ausencia de `mbstring` en PHP local; **no validado** el filtro HTTP de privacidad con una consulta válida.
- No se ha probado OpenAI ni IONOS.

## Limitaciones
El filtrado basado en expresiones regulares no garantiza impedir la salida de cualquier dato sensible. Los nuevos formatos detectan algunos identificadores, no todos. Antes del despliegue hay que probar con `mbstring` y verificar HTTP 422 para entradas sensibles, sin hacer llamadas externas.
