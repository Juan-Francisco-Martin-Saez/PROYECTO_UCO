# UCO 7.2E.18 — Prioridad de frases compuestas

Cambio limitado al orden de resultados del endpoint `public/api/assistant-catalog-71a.php`.

- Antes: después de coincidencias literales y por raíz contigua, los productos con todas las palabras en el nombre compartían el mismo nivel, independientemente del orden.
- Ahora: se añade un nivel intermedio para frases cuyos términos aparecen en el orden consultado (con palabras intercaladas), antes de las coincidencias dispersas en el nombre.
- El filtrado AND, los SKU, los formatos, el máximo de resultados y los metadatos no se modifican.
- No se modifica SQLite, el carrito, los pagos, los pedidos ni el prompt.

**Límite:** esta es una mejora de ranking, no una clasificación semántica de ingredientes ni una garantía de coincidencia exacta. Una frase con palabras intercaladas puede seguir corresponder a otro producto. Se requiere ensayo HTTP en un servidor con PHP PDO SQLite y mbstring antes de desplegar.
