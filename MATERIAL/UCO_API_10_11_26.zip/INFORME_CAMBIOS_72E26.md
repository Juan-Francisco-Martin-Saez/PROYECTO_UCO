# UCO 7.2E.26 — Endurecimiento del endpoint OpenAI

Cambios mínimos en `public/api/assistant-openai.php`:
- Validación estricta de `Content-Type: application/json` (permite parámetros como charset).
- Límite de 12.000 bytes sobre el cuerpo **real** además de Content-Length.
- `message` debe ser cadena: no se convierten objetos o arrays a texto.
- Lectura defensiva de los elementos `output` de la respuesta externa.

Sin modificaciones de prompt, identificadores, claves, buscador comercial, pedidos, pagos, bases de datos o frontend.

**Pendiente**: autenticación/limitación de tasa específica de este endpoint, a decidir según uso público o privado, y pruebas HTTP reales con PHP y cURL en entorno de despliegue. Las verificaciones locales no demuestran resistencia completa a abuso.
