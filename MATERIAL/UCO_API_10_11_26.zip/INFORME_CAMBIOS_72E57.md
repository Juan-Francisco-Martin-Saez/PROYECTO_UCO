# UCO 7.2E.57 — Revisión de prioridades entre pedidos y catálogo
Fecha: 10/11/2026.

## Alcance
Prueba directa de las funciones reales `contextualRoute`, `orderQuestion` e `isOwnDocumentQuery` mediante VM de Node. No se han modificado los módulos de producción, los datos, los pagos ni el prompt.

## Resultados
- 14/14 casos dirigidos superados: pedidos explícitos, seguimiento de estado/importe, cambio a catálogo, precios de producto, consultas de productos de un pedido, justificantes y preguntas generales.
- Regresión del router anterior: 42/42.
- Prueba de conversaciones largas 7.2E.56: ejecutada satisfactoriamente.
- Sintaxis JS y PHP: correcta.

## Limitaciones
Estas son pruebas locales de clasificación, no de ejecución de pedidos o carrito real. El motor general y el servidor IONOS no se han conectado. La clasificación depende de palabras clave y puede presentar ambigüedades no cubiertas por los casos dirigidos. En particular, las preguntas elípticas y las formulaciones mixtas no quedan exhaustivamente resueltas. No se ha cambiado la prioridad de producción sin evidencia de una regresión reproducible.

## Próximo paso
7.2E.58: ampliación de casos ambiguos de seguimiento de pedido, catálogo y carrito; decidir correcciones mínimas sobre fallos reproducibles.
