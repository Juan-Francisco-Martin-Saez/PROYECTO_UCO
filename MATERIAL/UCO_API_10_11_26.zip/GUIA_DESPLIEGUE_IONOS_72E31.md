# UCO 7.2E.31 — Preparación de validación en IONOS

**No se ha conectado ni desplegado nada en IONOS.** La fase entrega una comprobación local de requisitos y un procedimiento de verificación posterior al despliegue. No se modifican los archivos de producción.

## Antes de desplegar
1. Respaldar los archivos y las bases de datos del servidor y comprobar que se puede restaurar la versión 7.2E.30.
2. Confirmar la estructura de despliegue: `public/` debe ser la raíz pública y `private/` no debe poder consultarse por HTTP. **No subir la carpeta `private` dentro de la raíz pública**.
3. Ejecutar desde la raíz del proyecto: `php tests/preflight-ionos-72e31.php`. Revisar cualquier `FAIL`; la prueba no muestra claves.
4. Comprobar que la carpeta privada `private/logs/` permite crear `openai-rate-72e27/`, sin hacerla accesible públicamente.
5. Confirmar que `private/config/openai-protected.php` y el mecanismo de clave ya aprobado están presentes, sin copiarlos a registros ni compartir su contenido.

## Pruebas HTTP de solo lectura o con respuestas controladas
- `GET /api/assistant-openai.php` debe devolver `405`.
- `POST` con `Content-Type: text/plain` debe devolver `415`.
- `POST` JSON con `message` no textual debe devolver `422`.
- `POST` JSON con cuerpo de más de 12 KB debe devolver `413`.
- Una consulta válida puede consumir cuota de OpenAI: **hacerla solo con autorización**, verificar JSON `{ok:true,response:...}` y ausencia de importes comerciales.
- El test de `429` consume 11 solicitudes en un minuto y puede bloquear a usuarios que compartan IP; **ejecutarlo solo en ventana controlada**. Confirmar `Retry-After: 60`.
- Verificar `503` únicamente mediante una prueba controlada sin clave o con servicio simulado; **no desconfigurar la clave real**.
- Verificar en navegador búsquedas comerciales, consulta general, vuelta al carrito, contexto de pedidos y comando `IA:`. No introducir datos privados en `IA:`.

## Criterios de salida
- Todos los requisitos CLI correctos en el PHP real de IONOS.
- `private/` inaccesible por HTTP; permisos de escritura del limitador correctos.
- Una consulta real de OpenAI devuelve el formato esperado.
- Pruebas comerciales y de clientes sin regresiones.
- Procedimiento de reversión comprobado.

## Limitaciones conocidas
El limitador opera por IP, no por usuario; varias personas tras NAT comparten cuota. No hay purga automática de sus archivos de estado. La comprobación CLI es orientativa y no sustituye una prueba HTTP con la configuración real del alojamiento.
