# UCO 7.2E.48 — Auditoría de evasión de privacidad

- Cambios acotados a `public/assistant/assistant.js` y `public/api/assistant-openai.php`.
- Normalización NFKC (en PHP si `intl` está disponible), eliminación de invisibles Unicode, detección de identificadores fragmentados y algunas palabras comerciales espaciadas.
- `tests/test-privacy-evasion-72e48.py`: 30/30, ejecutando JavaScript real y HTTP PHP local.
- Regresiones: 28/28, 7/7 y enrutamiento 42/42.
- Sin llamadas reales a OpenAI ni IONOS; no se han probado todas las ofuscaciones posibles.
- PHP local requiere shim `mbstring` únicamente para las pruebas; el despliegue real debe disponer de `mbstring`.
- No se han tocado el prompt, pagos, pedidos ni bases de datos.
