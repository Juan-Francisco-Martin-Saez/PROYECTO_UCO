# UCO 7.2E.53 — Seguridad de excepciones contextuales

Se verificaron 28 consultas mixtas y variaciones con JavaScript y HTTP PHP real (31/31 incluyendo tres guardias estáticas). Se detectó y corrigió una divergencia: JavaScript admitía puntuación/comillas periféricas en preguntas didácticas exactas, mientras PHP las rechazaba. PHP ahora elimina únicamente signos de puntuación periféricos antes de comparar contra la lista cerrada; no elimina palabras adicionales ni ignora datos sensibles.

Regresiones ejecutadas: 38/38 (contexto 7.2E.51), 30/30 (7.2E.50), 30/30 (evasiones), 25/25 (auditoría cruzada), 28/28 JS privacidad, 42/42 enrutamiento real. La prueba cruzada 7.2E.47 necesitó limpiar el limitador de tasa local entre suites; inicialmente devolvió 429 por acumulación de solicitudes, no por privacidad.

Archivos de producción modificados: public/api/assistant-openai.php. No cambios en JS, prompt v2, pedidos, precios, pagos ni BD. Sin llamadas reales a OpenAI ni despliegue IONOS.

Limitación: lista de preguntas educativas exactas; no clasificador semántico general. Pruebas locales no equivalen a auditoría exhaustiva de seguridad.
