# UCO 7.2E.36 — Continuidad de conversaciones mixtas

## Alcance
Nueva batería de 7 secuencias y 32 comprobaciones para verificar el enrutamiento entre consultas generales y comerciales, sin modificar código de producción.

## Resultados
- `tests/test-mixed-dialogues-72e36.cjs`: 32/32 correctas.
- `tests/test-context-switch-72e34.cjs`: 18/18 correctas.
- `tests/test-context-switch-72e35.cjs`: 25/25 correctas.
- `tests/test-dialogos-prompt-72e33.cjs`: **falla una aserción** de la batería antigua. Requiere reconciliar sus expectativas con las reglas posteriores; no se ha alterado el comportamiento para hacerla pasar.

## Límites
Las pruebas simulan la clasificación de mensajes y verifican que esta no modifique el estado. No prueban respuestas reales de OpenAI, peticiones HTTP, persistencia del carrito, interfaz ni IONOS.

## Cambios
- Añadido `tests/test-mixed-dialogues-72e36.cjs`.
- Añadido este informe.
- No se han modificado archivos de producción, prompts, precios, pedidos, pagos ni bases de datos.
- La validación real en IONOS sigue aplazada hasta el final por petición del usuario.
