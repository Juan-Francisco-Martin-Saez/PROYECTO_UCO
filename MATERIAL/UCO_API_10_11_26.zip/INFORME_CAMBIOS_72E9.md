# 7.2E.9 — Pruebas funcionales HTTP

Esta entrega **añade un comprobador HTTP ejecutable** y no modifica el endpoint ni la base de datos.

## Ejecución

Desde la raíz de una **copia de pruebas** del proyecto:

```bash
python3 tests/test-assistant-http-72e9.py
```

Requisitos: PHP CLI con `pdo_sqlite` y `mbstring`, Python 3 y catálogo SQLite local. El script arranca un servidor PHP temporal en `127.0.0.1`, comprueba respuestas JSON reales (sin resultados, búsqueda solo por envase, referencia y consulta natural) y lo detiene. No requiere claves de OpenAI.

## Límites

En el entorno de empaquetado PHP no dispone de `pdo_sqlite` ni `mbstring`, por lo que **no se ha ejecutado** la prueba HTTP. No se certifica producción. La prueba devuelve código 2 (SKIP) si faltan extensiones.

No sobrescribir la base de datos de producción al desplegar una web completa. No hay cambios en precios, carrito, pedidos, administración ni prompt.
