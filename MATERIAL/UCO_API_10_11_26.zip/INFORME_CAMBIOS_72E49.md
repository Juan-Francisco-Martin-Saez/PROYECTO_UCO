# UCO 7.2E.49 — Auditoría de falsos positivos

- Batería nueva: 43/45 casos conformes, **2 falsos positivos detectados**.
- Casos bloqueados indebidamente: «¿Qué es el formato WAV en audio?» y «¿Qué es el catálogo de Messier en astronomía?».
- Motivo: bloqueo global de los términos «formato» y «catálogo» en JS y PHP, sin contexto semántico.
- Las 12 consultas comerciales o sensibles de control siguen bloqueadas.
- Regresiones: privacidad 28/28 + 7/7; enrutamiento 42/42.
- Sintaxis PHP y JS correcta.
- No se han cambiado archivos de producción: se recomienda acordar excepciones contextuales limitadas y probarlas en ambos filtros antes de desplegar.
- Sin conexiones reales a IONOS/OpenAI.
- Se borraron los contadores de cuota creados exclusivamente en la copia local de pruebas.
