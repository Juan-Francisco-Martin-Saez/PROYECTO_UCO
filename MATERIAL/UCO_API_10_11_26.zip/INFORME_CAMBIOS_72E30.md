# UCO 7.2E.30 — Auditoría final de integración (local)

**Alcance:** revisión de regresión, sintaxis, HTTP local y protección de integridad. No hay cambios de producción en esta fase.

## Estado
- Motor comercial y motor OpenAI: pruebas de enrutamiento y regresión ejecutadas localmente.
- Endpoint: respuestas HTTP locales y limitador por IP comprobados con entorno simulado.
- Integridad: se compararon hashes de los archivos críticos y bases de datos con 7.2E.29.
- El prompt OpenAI y su configuración permanecen intactos.

## Pendientes antes de producción
1. Confirmar PHP con mbstring y cURL en IONOS.
2. Confirmar permisos de `private/logs/openai-rate-72e27` y protección del directorio `private` frente a acceso web.
3. Validar una llamada real a OpenAI, respuesta de formato esperado y recuperación ante 503/429.
4. Comprobar la limitación por IP compartida y volumen real; los archivos del limitador no tienen purga automática.
5. Verificar en navegador conversaciones comerciales, consultas generales y cambios de contexto con sesión real.
6. Revisar el tratamiento de consultas sensibles, incluida la ruta explícita `IA:`.

**Importante:** pasar estas pruebas no equivale a certificar el despliegue real. No modificar el prompt sin autorización expresa.

Resultados detallados en `INFORME_VALIDACION_72E30.json`.
