# UCO 7.2E.32 — Contrato y propuesta de prompt

- Se incorporan pruebas estáticas del contrato actual entre frontend, endpoint y prompt.
- Se documentan reglas propuestas y casos de aceptación, sin modificar el prompt remoto ni su configuración.
- Se pospone la validación IONOS y la conexión real a OpenAI hasta la fase final, por indicación del propietario.
- No se modifica ningún archivo de producción, base de datos, clave, precio, pedido o pago.
