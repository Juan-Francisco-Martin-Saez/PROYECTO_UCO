# UCO 7.2E.44 — Coordinación de tiempos de espera

- `public/api/assistant-openai.php`: conexión cURL limitada a 5 segundos y tiempo total cURL a 16 segundos.
- `public/assistant/assistant.js`: sin cambios; su aborto sigue en 20 segundos, dejando 4 segundos de margen nominal.
- Los límites de cURL no garantizan el tiempo total de ejecución PHP ni la latencia del servidor web; se comprobarán en IONOS al final.
- Pruebas automatizadas de configuración, protección previa y error de red sin acceso a OpenAI.
- No se modifican prompt, carrito, pedidos, pagos ni bases de datos.
