# UCO 7.2E.38 — Resistencia conversacional

Se añade una prueba determinista de **40 sesiones × 100 turnos = 4000 clasificaciones** del enrutador real `shouldUseGeneralEngine72e22`, ejecutado con dependencias de contexto simuladas.

Resultado: {"sessions":40,"checks":4000,"blockedGeneral":400,"allowedGeneral":1600,"retainedLocal":2000,"status":"PASS"}

Regresiones: {
  "test-mixed-dialogues-72e36.cjs": {
    "exit": 0,
    "stdout": "{\"passed\":32,\"total\":32,\"sessions\":7,\"status\":\"OK\"}\n",
    "stderr": ""
  },
  "test-context-switch-72e35.cjs": {
    "exit": 0,
    "stdout": "25/25 pruebas de cambio de contexto superadas\n",
    "stderr": ""
  },
  "test-context-switch-72e34.cjs": {
    "exit": 0,
    "stdout": "18/18 pruebas de cambio de contexto superadas\n",
    "stderr": ""
  },
  "test-dialogos-prompt-72e33.cjs": {
    "exit": 0,
    "stdout": "32/32 casos de enrutamiento con funciones reales extraídas del JS. Sin llamadas a OpenAI.\n",
    "stderr": ""
  }
}

**Alcance:** estas pruebas no ejecutan interfaz, respuestas OpenAI, HTTP, almacenamiento de carrito ni servidor IONOS. El contexto comercial está simulado y el test comprueba que la función no lo modifica. No se han cambiado archivos de producción, claves, prompts, pedidos, precios ni pagos. Validación real IONOS pospuesta.
