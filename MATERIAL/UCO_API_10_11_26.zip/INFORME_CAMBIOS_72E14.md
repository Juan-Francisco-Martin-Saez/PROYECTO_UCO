# Fase 7.2E.14 — Priorización de nombre frente a ingredientes secundarios

- Mantiene intactos los filtros AND, referencias, formatos y sinónimos.
- Incorpora al ranking una coincidencia por raíz léxica en el nombre oficial, antes de las coincidencias exclusivamente en categoría, descripción o texto de búsqueda.
- Favorece los productos cuyo nombre comienza por el término solicitado.
- No elimina productos compuestos; los relega cuando solo coinciden por descripción.
- Prueba estructural en `tests/test-assistant-catalog-primary-72e14.py`.

**Limitación:** no existe aún una clasificación explícita y completa de ingredientes principales/secundarios en el catálogo. Esta fase mejora el ranking por campos, no determina semánticamente los ingredientes. Requiere pruebas HTTP en PHP con pdo_sqlite y mbstring antes de producción.
