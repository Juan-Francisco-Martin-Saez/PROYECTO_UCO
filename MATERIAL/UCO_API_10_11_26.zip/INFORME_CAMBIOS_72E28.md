# UCO 7.2E.28 — Validación HTTP local y plan de despliegue

- Añadido `tests/test-http-local-72e28.py`: 3 pruebas HTTP reales contra servidor PHP local (GET 405, Content-Type 415, tamaño 413), sin llamadas a OpenAI.
- Reejecutado `tests/test-openai-rate-72e27.php`: 13/13 controles de limitación superados.
- Añadida guía `tests/PRUEBAS_IONOS_72E28.md` con comprobaciones de IONOS y respuesta 429.
- **No hay cambios en producción**, prompt, claves, catálogo, pedidos, pagos ni SQLite.
- **Pendiente**: prueba HTTP con mensaje válido y prueba 429 integrada, debido a la falta de `mbstring` y `curl` en PHP local; tampoco se ha desplegado en IONOS.
