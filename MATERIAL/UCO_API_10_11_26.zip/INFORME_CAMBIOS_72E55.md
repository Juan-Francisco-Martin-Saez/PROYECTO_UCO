# UCO Sa Pobla 2.0 — Fase 7.2E.55

## Objetivo
Comprobar estabilidad ante fallos consecutivos del motor general y recuperación sin afectar al motor comercial.

## Resultado de nueva prueba
- 192 interacciones del controlador real de envío, con servicios simulados.
- 60 fallos consecutivos simulados de OpenAI (HTTP 503, 429, 500, red, timeout, JSON inválido).
- 125 operaciones comerciales simuladas (catálogo y pedidos) continuaron funcionando.
- 4 bloqueos de privacidad antes de acceder a la red.
- 4 bloqueos de derivación por contexto comercial activo.
- 62 peticiones simuladas a OpenAI y 62 limpiezas de temporizador.
- Recuperación del motor general después de 60 fallos.

## Alcance y límites
No se ha modificado código de producción, base de datos, prompt, pedidos, pagos ni precios. El controlador de envío y la función de acceso protegido a OpenAI se ejecutaron desde el código real; los servicios comerciales y la red fueron simulados. No se probó IONOS ni la API real de OpenAI. No equivale a una prueba de navegador o de carga real.
