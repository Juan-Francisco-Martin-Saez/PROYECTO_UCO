# UCO — Fase 7.2E.11 — Evaluación de precisión

## Alcance
Se incorpora `tests/test-catalog-precision-72e11.py` y `tests/RESULTADOS_72E11.json`.
No hay modificaciones de código de producción ni escrituras en SQLite.

## Resultados
- 3 de 4 expectativas léxicas cumplidas.
- `aros cebolla`: 2 coincidencias; al menos una con «aros» en el nombre.
- Consulta inexistente: 0 coincidencias.
- `zanahoria`: 11 coincidencias; al menos una con «zanahoria» en el nombre.
- `patatas`: 0 coincidencias en la aproximación léxica Python. **Investigar** normalización plural/singular y sinónimos en PHP antes de declarar incidencia del endpoint.
- Consultas directas SQL sobre presentaciones: se encontraron registros de 1 kg, 6 kg y envases múltiples.

## Límites
El test léxico Python no reproduce exactamente el endpoint PHP y no verifica ranking real, HTTP, ni respuestas JSON. No se ha ejecutado el PHP por falta de extensiones requeridas en este entorno.

## Próxima fase propuesta
7.2E.12: casos de plural/singular y variantes léxicas, con pruebas funcionales HTTP cuando haya un entorno PHP compatible.
