# UCO 7.2E.43 — Auditoría de fallos y recuperación

- Pruebas de la función real `askProtectedOpenAI` en un entorno JavaScript aislado con red simulada.
- Casos: respuesta válida, HTTP 400/401/403/404/408/422/429/500/502/503/504, respuesta no válida, JSON corrupto, error de red y aborto.
- La función devuelve `null` ante fallos, libera el temporizador y no llama a la API si detecta datos sensibles.
- La interfaz muestra un mensaje informativo cuando falla OpenAI; el siguiente turno no queda bloqueado por esa función.
- Limitación: no se ha ejecutado una prueba de navegador de extremo a extremo ni una llamada real al proveedor.
- Observación: timeout del navegador 20 s; timeout cURL PHP 30 s. El navegador puede desistir antes de que termine la petición del servidor.
- Sin modificaciones en producción, prompt, precios, pedidos, pagos o base de datos. IONOS y OpenAI reales quedan pendientes.
