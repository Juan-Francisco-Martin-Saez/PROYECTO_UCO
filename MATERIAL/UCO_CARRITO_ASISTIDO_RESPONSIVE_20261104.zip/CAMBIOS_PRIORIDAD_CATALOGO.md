# Catálogo priorizado desde el chatbot

- Home y clientes: la búsqueda conversacional reordena sin eliminar productos.
- Coincidencias primero, después productos de las familias implicadas y finalmente el resto.
- Paginación aplicada al orden completo en el servidor, no solo a la página visible.
- Búsqueda manual del catálogo mantiene su filtro habitual.
- Nuevo chat limpia las prioridades; el prepedido sigue independiente.
- Sin cambios en administración ni bases de datos.

Pruebas realizadas: validación de sintaxis PHP y JavaScript, integridad del ZIP. No se ha probado en navegador con sesión real.
