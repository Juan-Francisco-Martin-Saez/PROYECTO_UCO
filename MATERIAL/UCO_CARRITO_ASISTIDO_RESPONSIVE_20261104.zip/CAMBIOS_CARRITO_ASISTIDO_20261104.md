# Carrito asistido · 04-11-2026

- Tras un traspaso correcto, se vacía el prepedido y se cierra el panel comercial. Se abre el carrito nativo, sin cerrar el chat.
- El resumen se obtiene del carrito autenticado y la API de cotización, sin precios inventados.
- El asistente explica las etapas de revisión, reserva y pago, sin realizar acciones sensibles por sí mismo.
- Vista de escritorio en dos columnas y vista móvil dividida verticalmente, con scroll interno.
- El botón de cerrar carrito restaura la disposición anterior.
- Administración y bases SQLite sin cambios.

## Precauciones
No se han ejecutado pruebas de compra/pago ni pruebas visuales en navegador. Comprobar especialmente sesiones, IVA/transporte, reserva, accesibilidad y pantallas móviles. No sobrescribir bases de datos de producción.
