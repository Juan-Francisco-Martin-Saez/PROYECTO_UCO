AJUSTE SCROLL PREPEDIDO
- Panel flotante: ancho máximo 570 -> 592 px, cuando el espacio de pantalla lo permite.
- Listado: 12 px interiores a la derecha para separar contenido y scrollbar.
- Se conserva límite visual de tres referencias, botones y total fuera del scroll.
- No modifica administración, pedidos ni SQLite.
- Si el navegador tiene poco espacio, el panel conserva su ancho adaptable.
