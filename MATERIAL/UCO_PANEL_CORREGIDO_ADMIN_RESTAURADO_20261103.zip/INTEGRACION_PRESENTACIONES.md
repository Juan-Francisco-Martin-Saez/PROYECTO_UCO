# Integración de presentaciones — 03/11/2026

- Fuente: `uco_presentaciones` en SQLite. Las API de catálogo público, clientes, administración (listado) y precios autenticados incluyen `presentacion`.
- Catálogo público: el modal muestra el desglose de la variante seleccionada.
- Área de clientes: la tarjeta muestra el desglose; el precio conserva su valor y unidad comercial previa, sin inferir €/kg o €/caja.
- Asistente: la API de precios autenticados incluye el desglose; la búsqueda semántica principal sigue pendiente de integrarlo en todas sus rutas de respuesta. No se cambian las reglas de pedidos.
- Administración: los datos se exponen para visualización, pero NO se han añadido controles de edición de presentaciones.
- Normalización de nombres en tarjetas: conectores intermedios en minúscula; originales conservados.
- NO sobrescribir SQLite de producción: aplicar la migración existente tras respaldo.
- No se ha ejecutado una prueba end-to-end en servidor ni se ha verificado visualmente el resultado.
