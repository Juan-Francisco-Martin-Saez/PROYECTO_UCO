# UCO Sa Pobla 2.0 — prepedidos conversacionales y búsqueda limpia

Base: UCO_PREPEDIDOS_CONVERSACIONALES_20261103.zip.

## Conservado de la versión anterior
- Búsqueda de uno o varios productos, selección de referencia, cantidad y tarifa autenticada.
- Prepedido acumulativo (hasta 100 referencias), persistido en sessionStorage de la pestaña.
- Traspaso al carrito existente bajo confirmación, sin crear pedidos ni cobrar desde el asistente.
- Filtro del catálogo y estructura de presentaciones comerciales.

## Añadido
- Botón y orden «Nueva búsqueda»: limpia las tarjetas de resultados previos y el filtro guardado, pero no el prepedido.
- Botón y orden «Mis pedidos» / «historial»: consulta GET /api/orders.php?action=history con la sesión autenticada y muestra los últimos cinco pedidos.
- Vista compacta de líneas y enlace al historial completo del área de clientes.
- «Preparar de nuevo» recupera las referencias por SKU exacto, añade cantidades al prepedido actual y marca las no localizadas. No reutiliza precios antiguos; exige revisión de tarifas/stock actuales.
- En la web pública, el historial requiere entrar al área de clientes.

## Precauciones
- El historial usa únicamente el endpoint existente y no almacena datos de pedidos anteriores en sessionStorage.
- Repetir un pedido no implica confirmarlo, reservar stock ni cobrar.
- No reemplazar SQLite de producción por la incluida en el ZIP.
- Pruebas ejecutadas: node --check de prepedido.js y php -l de orders.php. Pendiente prueba funcional real con sesiones y navegador.
