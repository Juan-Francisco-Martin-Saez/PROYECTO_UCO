# UCO · Panel comercial flotante

- Área de clientes: cuatro accesos en una fila, cinco cuando existe prepedido.
- Resultados, variantes, cantidades, prepedido e historial en un panel comercial independiente.
- Chat dedicado a mensajes de conversación.
- Nuevo chat limpia mensajes y panel de resultados, sin borrar el prepedido.
- Mis pedidos consulta exclusivamente /api/orders.php?action=history bajo la sesión de cliente; desde público redirige a /clientes/.
- Administración intacta: no se alteran sus scripts ni sus botones.

No reemplazar la base SQLite de producción. Probar sesiones simultáneas admin/cliente y la interfaz en móvil antes de desplegar.
