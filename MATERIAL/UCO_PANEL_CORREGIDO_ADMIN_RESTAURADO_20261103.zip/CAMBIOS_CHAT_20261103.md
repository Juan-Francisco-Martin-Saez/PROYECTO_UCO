# Ajustes del chatbot UCO

- Web pública: ocho botones en una sola fila, más compactos, sin alterar el diseño del área de clientes.
- «Nueva búsqueda» pasa a «Nuevo chat». Limpia todos los mensajes y resultados visibles, además del historial conversacional persistido en sessionStorage.
- El prepedido comercial se conserva para no perder artículos seleccionados. «Mis pedidos» mantiene su comportamiento.
- Administración: se retiran las cargas del asistente y de sus estilos; no se modifica el resto de administración.
- Se actualizan las versiones de recursos para evitar caché de archivos antiguos.

No reemplazar bases de datos de producción.
