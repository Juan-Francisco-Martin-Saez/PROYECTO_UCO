# Presentaciones comerciales UCO — revisión segura

La tabla `uco_presentaciones` conserva el formato original y separa `envases`, `peso_envase_kg`, `peso_total_kg`, `tipo_envase` y `estado`. Los registros de `peso conocido; envases por confirmar` NO indican que se trate de un único envase. Tampoco se presupone que el precio vigente sea por kg o por caja.

Ejecutar `python3 tools/normalizar-presentaciones-uco.py` sobre una copia respaldada de la base real antes de desplegar. La base incluida es una copia de trabajo, no debe reemplazar la de producción. Para la visualización futura, mostrar `N envases × X kg = Y kg` solo con estado `desglosado`; en otros casos mostrar el peso conocido y `Presentación por confirmar`. El precio debe llevar su unidad comercial verificada antes de mostrarse como €/kg o €/caja.

Esta fase prepara y rellena los datos; **no conecta todavía la tabla a todas las fichas, al panel administrativo ni a las respuestas del chatbot**. Esas integraciones requieren modificar y probar los puntos de consulta y representación correspondientes.
