# Corrección del panel comercial y Nuevo chat

- Nuevo chat borra los mensajes y la búsqueda anterior, pero no el prepedido guardado. Si existen referencias, muestra el prepedido en el panel flotante, no dentro del chat.
- Las búsquedas breves por nombre de producto sin verbo inicial también se encaminan al panel comercial, con selector y cantidad, en lugar de generar la lista textual anterior.
- Si la frase no tiene coincidencias de catálogo, se conserva el asistente general existente.
- Se invalidan búsquedas asíncronas anteriores cuando se inicia un chat nuevo para evitar que sus resultados reaparezcan.
- Se incrementa la versión del script para evitar caché.
- No se modifican las bases SQLite, el chatbot administrativo, las tarifas ni los pedidos.

## Pruebas pendientes
Probar con sesión real en navegador, especialmente búsquedas simultáneas, panel móvil y transferencia al carrito. No sustituir las bases SQLite del servidor.
