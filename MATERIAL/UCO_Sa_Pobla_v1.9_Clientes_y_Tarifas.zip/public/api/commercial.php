<?php
declare(strict_types=1);
function commercialDb(PDO $db):void{
 $db->exec("CREATE TABLE IF NOT EXISTS customer_groups(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL COLLATE NOCASE UNIQUE,active INTEGER NOT NULL DEFAULT 1)");
 $db->exec("CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,company TEXT NOT NULL,tax_id TEXT NOT NULL DEFAULT '',contact TEXT NOT NULL DEFAULT '',email TEXT NOT NULL COLLATE NOCASE UNIQUE,password_hash TEXT NOT NULL,group_id INTEGER REFERENCES customer_groups(id) ON DELETE SET NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)");
 $db->exec("CREATE TABLE IF NOT EXISTS group_prices(group_id INTEGER NOT NULL REFERENCES customer_groups(id) ON DELETE CASCADE,product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,price_cents INTEGER NOT NULL CHECK(price_cents>=0),PRIMARY KEY(group_id,product_id))");
 $db->exec("CREATE TABLE IF NOT EXISTS customer_prices(customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,price_cents INTEGER NOT NULL CHECK(price_cents>=0),PRIMARY KEY(customer_id,product_id))");
 $db->exec("CREATE INDEX IF NOT EXISTS idx_customers_group ON customers(group_id)");
}
function customerPublic(array $c):array{return ['id'=>(int)$c['id'],'company'=>$c['company'],'tax_id'=>$c['tax_id'],'contact'=>$c['contact'],'email'=>$c['email'],'group_id'=>$c['group_id']===null?null:(int)$c['group_id'],'active'=>(int)$c['active']];}
function priceCents(string $raw):?int{if(!preg_match('/^\d{1,8}(?:[.,]\d{1,2})?$/',$raw))return null;$v=explode('.',str_replace(',','.',$raw));return (int)$v[0]*100+(int)str_pad($v[1]??'',2,'0');}
