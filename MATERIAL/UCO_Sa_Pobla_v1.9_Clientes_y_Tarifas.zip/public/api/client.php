<?php
declare(strict_types=1);
ini_set('display_errors','0');header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');
ini_set('session.use_strict_mode','1');session_name('UCOCLIENT');session_set_cookie_params(['httponly'=>true,'secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','samesite'=>'Strict','path'=>'/']);session_start();
require_once __DIR__.'/commercial.php';
function reply(array $a,int $status=200):never{http_response_code($status);echo json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function connect():PDO{$db=new PDO('sqlite:'.dirname(__DIR__,2).'/private/database/catalogo.sqlite',null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);$db->exec('PRAGMA foreign_keys=ON');$db->exec('PRAGMA busy_timeout=5000');return $db;}
$action=(string)($_GET['action']??'session');$method=$_SERVER['REQUEST_METHOD'];
try{
 $db=connect();commercialDb($db);
 if($action==='login'&&$method==='POST'){
  $email=mb_strtolower(trim((string)($_POST['email']??'')),'UTF-8');$pass=(string)($_POST['password']??'');$st=$db->prepare('SELECT * FROM customers WHERE email=? COLLATE NOCASE LIMIT 1');$st->execute([$email]);$u=$st->fetch();
  if(!$u||!(int)$u['active']||!password_verify($pass,$u['password_hash'])){usleep(450000);reply(['error'=>'Credenciales incorrectas o cuenta desactivada.'],401);}
  session_regenerate_id(true);$_SESSION['customer_id']=(int)$u['id'];$_SESSION['customer_stamp']=hash('sha256',$u['password_hash']);$_SESSION['customer_csrf']=bin2hex(random_bytes(32));reply(['ok'=>true,'csrf'=>$_SESSION['customer_csrf'],'customer'=>customerPublic($u)]);
 }
 if($action==='session'&&$method==='GET'&&!isset($_SESSION['customer_id']))reply(['authenticated'=>false]);
 if(!isset($_SESSION['customer_id']))reply(['error'=>'Acceso restringido'],401);
 $st=$db->prepare('SELECT * FROM customers WHERE id=? AND active=1');$st->execute([$_SESSION['customer_id']]);$u=$st->fetch();
 if(!$u||!hash_equals((string)($_SESSION['customer_stamp']??''),hash('sha256',$u['password_hash']))){$_SESSION=[];session_destroy();reply(['authenticated'=>false,'error'=>'La sesión ha caducado'],401);}
 if($action==='session'&&$method==='GET')reply(['authenticated'=>true,'csrf'=>$_SESSION['customer_csrf'],'customer'=>customerPublic($u)]);
 if($action==='logout'&&$method==='POST'){
  if(!hash_equals((string)$_SESSION['customer_csrf'],(string)($_SERVER['HTTP_X_CSRF_TOKEN']??'')))reply(['error'=>'Solicitud no válida'],403);
  $_SESSION=[];session_destroy();reply(['ok'=>true]);
 }
 if($action==='change_password'&&$method==='POST'){
  if(!hash_equals((string)$_SESSION['customer_csrf'],(string)($_SERVER['HTTP_X_CSRF_TOKEN']??'')))reply(['error'=>'Solicitud no válida'],403);
  $old=(string)($_POST['old_password']??'');$new=(string)($_POST['new_password']??'');if(!password_verify($old,$u['password_hash']))reply(['error'=>'Contraseña actual incorrecta'],422);if(strlen($new)<12||strlen($new)>256)reply(['error'=>'La contraseña debe tener entre 12 y 256 caracteres'],422);
  $hash=password_hash($new,PASSWORD_DEFAULT);$db->prepare('UPDATE customers SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$hash,$u['id']]);$_SESSION['customer_stamp']=hash('sha256',$hash);reply(['ok'=>true]);
 }
 if($action==='catalog'&&$method==='GET'){
  $page=max(1,min(100000,(int)($_GET['page']??1)));$limit=12;$q=trim((string)($_GET['q']??''));if(mb_strlen($q)>100)reply(['error'=>'Búsqueda demasiado larga'],400);
  $where=' WHERE p.active=1 AND c.active=1';$args=[];if($q!==''){$where.=" AND (p.name LIKE :qname ESCAPE '!' OR p.sku LIKE :qsku ESCAPE '!')";$term='%'.str_replace(['!','%','_'],['!!','!%','!_'],$q).'%';$args[':qname']=$term;$args[':qsku']=$term;}
  $from=' FROM products p JOIN categories c ON c.id=p.category_id';$st=$db->prepare('SELECT COUNT(*)'.$from.$where);$st->execute($args);$total=(int)$st->fetchColumn();
  $sql="SELECT p.id,p.sku,p.name,p.description,p.unit,p.image,p.stock,c.name AS family,COALESCE(cp.price_cents,gp.price_cents) AS price_cents,CASE WHEN cp.price_cents IS NOT NULL THEN 'personal' WHEN gp.price_cents IS NOT NULL THEN 'grupo' ELSE NULL END AS price_source".$from." LEFT JOIN customer_prices cp ON cp.product_id=p.id AND cp.customer_id=:customer LEFT JOIN customer_groups cg ON cg.id=:grp AND cg.active=1 LEFT JOIN group_prices gp ON gp.product_id=p.id AND gp.group_id=cg.id".$where.' ORDER BY p.name COLLATE NOCASE,p.id LIMIT :limit OFFSET :offset';
  $st=$db->prepare($sql);$st->bindValue(':customer',(int)$u['id'],PDO::PARAM_INT);$st->bindValue(':grp',(int)($u['group_id']??0),PDO::PARAM_INT);foreach($args as $k=>$v)$st->bindValue($k,$v);$st->bindValue(':limit',$limit,PDO::PARAM_INT);$st->bindValue(':offset',($page-1)*$limit,PDO::PARAM_INT);$st->execute();
  $group=null;if($u['group_id']){$g=$db->prepare('SELECT name FROM customer_groups WHERE id=? AND active=1');$g->execute([$u['group_id']]);$group=$g->fetchColumn()?:null;}
  reply(['products'=>$st->fetchAll(),'total'=>$total,'page'=>$page,'limit'=>$limit,'group'=>$group]);
 }
 reply(['error'=>'Operación no permitida'],405);
}catch(Throwable $e){error_log('UCO clientes: '.$e->getMessage());reply(['error'=>'No se pudo completar la operación'],500);}
