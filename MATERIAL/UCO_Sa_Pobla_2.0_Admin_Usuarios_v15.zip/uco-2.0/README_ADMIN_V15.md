# UCO Sa Pobla 2.0 — Panel de administración v1.5

## Actualizar desde la versión 1.4 SIN PERDER DATOS

**IMPORTANTE:** antes de actualizar, realiza una copia de seguridad de `private/database/catalogo.sqlite` y de `public/img/productos/` de tu instalación actual. Al extraer este ZIP sobre tu proyecto, **NO sobrescribas** esos dos elementos: el ZIP contiene una base de datos de demostración y no puede incluir los productos reales que has introducido en tu ordenador. Copia los nuevos archivos de `public/api/admin.php`, `public/admin/admin.js` y `public/admin/admin.css` sobre los anteriores; esos tres archivos son suficientes para pasar de la v1.4 a la v1.5. Los demás archivos se mantienen como en v1.4.

## Primer acceso

Inicia PHP desde `public`: `C:\php\php.exe -S localhost:8000` y abre `http://localhost:8000/admin/`.

Nombre de usuario inicial: **Administrador**. Contraseña inicial: **la que ya configuraste en `UCO_ADMIN_PASSWORD_HASH`**. En el primer inicio de sesión correcto se crea automáticamente en la misma SQLite la cuenta Administrador, con rol de administrador principal. No se incluye ninguna contraseña ni hash real en este paquete. La variable `UCO_ADMIN_PASSWORD_HASH` debe seguir configurada para esa primera migración. Después, la cuenta se autentica desde SQLite y puedes cambiar la contraseña desde el panel sin editar variables de entorno. Si ya existe algún usuario en `admin_users`, la creación automática no se ejecuta.

## Usuarios y seguridad

El botón «Usuarios y seguridad» aparece en la cabecera del panel. Un administrador principal puede crear, editar, activar, desactivar y eliminar usuarios, así como asignar roles de **Administrador principal** o **Gestor de catálogo**. Un gestor puede gestionar productos y cambiar su propia contraseña, pero no administrar otras cuentas. Se impide eliminar la propia cuenta o dejar el sistema sin administradores activos. Las contraseñas se guardan con `password_hash()`, nunca en texto plano. Mínimo 12 caracteres. Cambiar una contraseña invalida las sesiones anteriores de esa cuenta.

## Requisitos y seguridad

PHP 8.1+ con PDO_SQLite, mbstring y GD; servidor HTTPS para producción; carpeta `private` fuera de la raíz pública; permisos de escritura en SQLite. Es recomendable configurar limitación de intentos de acceso a nivel servidor, copias de seguridad y auditoría de accesos antes de la puesta en producción. El servidor PHP integrado se usa solo en desarrollo.
