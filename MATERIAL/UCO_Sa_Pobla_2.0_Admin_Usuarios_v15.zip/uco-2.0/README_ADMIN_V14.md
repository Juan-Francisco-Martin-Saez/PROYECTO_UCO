# UCO Sa Pobla 2.0 — Administración v1.4

## Requisitos
PHP 8.1+, extensiones PDO_SQLite, mbstring y GD (para fotos); HTTPS en producción. Servir la carpeta `public` como raíz web y mantener `private` fuera del directorio público. `public/img/productos` debe ser escribible por PHP y `private/database/catalogo.sqlite` y su carpeta deben ser escribibles por PHP. No publicar la base de datos ni usar contraseñas en el código.

## Configurar contraseña
Generar hash desde terminal con PHP: `php -r 'echo password_hash("TU_CLAVE_SEGURA", PASSWORD_DEFAULT), PHP_EOL;'`.
Configurar variable de entorno `UCO_ADMIN_PASSWORD_HASH` con ese hash **en la configuración del servidor**, no en archivos públicos. Reiniciar PHP si es necesario. Sin la variable el panel **no permite iniciar sesión**. Acceso: `/admin/`.

## Stock
Stock es un contador entero de unidades (no peso). 0 significa «Sin stock». El estado Activo/Inactivo es independiente: un producto activo puede no tener existencias. El inventario de esta versión se gestiona manualmente; no se sincroniza con GESCOM.

## Imágenes
Se aceptan JPG, PNG y WebP hasta 12 MB. PHP GD genera WebP de 960×720 sobre fondo neutro, centrando la foto sin deformar ni ampliar imágenes pequeñas. Para preservar calidad original, guardar el archivo original por separado si se necesita en el futuro.

## Datos existentes
Se conserva el catálogo de demostración. Los registros previos reciben stock=0 y observaciones vacías. La búsqueda se realiza sobre una columna normalizada sin tildes. La API pública no expone observaciones ni productos inactivos. Para instalar sobre una base SQLite distinta, aplicar las migraciones de las columnas `stock`, `notes`, `search_text` y rellenar `search_text` con nombres y códigos normalizados antes de usar el panel.

## Seguridad y limitaciones
Autenticación con hash en variable de entorno, sesión HTTP-only SameSite Strict y token CSRF. Las peticiones de imágenes se validan y se renombran aleatoriamente. Antes de producción, configurar HTTPS, limitación de intentos de login en servidor, copias de seguridad y permisos de carpetas. La tabla muestra hasta 2000 productos por consulta; paginación del panel queda para una fase posterior.
