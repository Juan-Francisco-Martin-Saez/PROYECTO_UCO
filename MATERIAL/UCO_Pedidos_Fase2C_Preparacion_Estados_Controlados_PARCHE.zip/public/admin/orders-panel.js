const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=v=>(Number(v||0)/100).toLocaleString('es-ES',{style:'currency',currency:'EUR'});
const states={pending_preparation:'Pendiente de preparación',preparing:'En preparación',prepared:'Preparado',dispatched:'Enviado',delivered:'Entregado',incident:'Incidencia',cancelled:'Cancelado'};
export async function openAdminOrders(){
 const el=document.createElement('section');el.id='orders-area';el.className='wrap uco-orders';
 el.innerHTML=`<div class="uco-orders-intro"><div><span class="eyebrow">PEDIDOS · ADMINISTRACIÓN</span><h1>Gestión de <em>pedidos.</em></h1><p>Consulta de pagos, productos y preparación. Los pedidos históricos no entran automáticamente en almacén.</p></div></div><section class="panel"><div class="uco-orders-filters"><label>Buscar pedido o cliente<input type="search" id="uco-orders-search" placeholder="PED-08, Pepe..."></label><label>Pago<select id="uco-orders-payment"><option value="">Todos</option><option value="yes">Aprobado</option><option value="no">Sin confirmar</option></select></label><label>Preparación<select id="uco-orders-state"><option value="">Todos</option><option value="none">Sin iniciar</option>${Object.entries(states).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select></label></div><div class="uco-orders-count" aria-live="polite">Cargando pedidos…</div><div class="uco-orders-list"></div></section>`;
 document.querySelector('.admin-section-nav').after(el);
 const list=el.querySelector('.uco-orders-list'),count=el.querySelector('.uco-orders-count');
 try{
  const response=await fetch('../api/admin-orders.php',{credentials:'same-origin',cache:'no-store'});
  const data=await response.json();
  if(!response.ok)throw Error(data.error||'Error de consulta');
  const orders=data.orders||[];const canManage=!data.read_only;
  const allowed={none:['pending_preparation'],pending_preparation:['preparing','incident','cancelled'],preparing:['prepared','incident'],prepared:['dispatched','incident'],dispatched:['delivered','incident'],incident:['pending_preparation','cancelled']};
  const render=()=>{
   const search=el.querySelector('#uco-orders-search').value.trim().toLocaleLowerCase('es');
   const payment=el.querySelector('#uco-orders-payment').value,state=el.querySelector('#uco-orders-state').value;
   const filtered=orders.filter(o=>(!search||('ped-'+String(o.id).padStart(2,'0')+' '+o.customer+' '+o.id).toLocaleLowerCase('es').includes(search))&&(!payment||((payment==='yes')===!!o.payment_confirmed))&&(!state||(state==='none'?!o.fulfillment_state:o.fulfillment_state===state)));
   count.textContent=`${filtered.length} pedidos · ${canManage?'Gestión autorizada':'Consulta protegida'}`;
   list.innerHTML=filtered.length?filtered.map(o=>`<details class="uco-order-card"><summary><strong>PED-${String(o.id).padStart(2,'0')}</strong><span>${esc(o.customer)}</span><span>${esc(o.created_at)}</span><strong>${money(o.total_cents??o.subtotal_cents)}</strong><span class="uco-order-status">${o.payment_confirmed?'Pago aprobado':'Pago sin confirmar'}</span><span class="uco-order-state">${esc(states[o.fulfillment_state]||'Sin iniciar')}</span></summary><div class="uco-order-detail"><p><strong>Cliente:</strong> ${esc(o.customer)} · <strong>Forma de pago:</strong> ${esc(({redsys:'Tarjeta bancaria (Visa / Mastercard)',paypal:'PayPal',bizum:'Bizum',transfer:'Transferencia bancaria'})[o.payment_method]||o.payment_method||'—')}</p><div class="uco-order-lines">${o.lines.map(l=>`<div><span>${esc(l.name)} <small>${esc(l.sku)}</small></span><span>${Number(l.quantity)} ${esc(l.unit)}</span><strong>${money(l.line_cents)}</strong></div>`).join('')}</div>${canManage&&o.payment_confirmed?`<div class="uco-order-actions"><label>Estado siguiente<select data-next="${o.id}">${(allowed[o.fulfillment_state||'none']||[]).map(s=>`<option value="${s}">${esc(states[s])}</option>`).join('')}</select></label><button type="button" data-save="${o.id}" ${(allowed[o.fulfillment_state||'none']||[]).length?'':'disabled'}>Actualizar estado</button></div>`:'<p class="uco-order-notice">Sin cambios disponibles para esta cuenta o pedido.</p>'}</div></details>`).join(''):'<p class="uco-order-empty">No hay pedidos con estos filtros.</p>';
  };
  el.querySelectorAll('.uco-orders-filters input,.uco-orders-filters select').forEach(x=>x.addEventListener('input',render));
  list.addEventListener('click',async ev=>{
   const button=ev.target.closest('button[data-save]');if(!button||button.disabled)return;
   const id=Number(button.dataset.save),select=list.querySelector(`select[data-next="${id}"]`),state=select?.value;
   if(!state)return;
   if(!confirm(`¿Cambiar el pedido PED-${String(id).padStart(2,'0')} a "${states[state]}"?`))return;
   button.disabled=true;
   try{
    const sessionResponse=await fetch('../api/admin.php?action=session',{credentials:'same-origin',cache:'no-store'});
    const session=await sessionResponse.json();
    if(!session.authenticated||!session.csrf)throw Error('Sesión caducada');
    const response=await fetch('../api/admin-orders.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':session.csrf},body:JSON.stringify({order_id:id,state})});
    const result=await response.json();
    if(!response.ok)throw Error(result.error||'No se pudo actualizar');
    const order=orders.find(o=>Number(o.id)===id);order.fulfillment_state=state;render();
   }catch(error){alert(error.message);button.disabled=false;}
  });
  render();
 }catch(e){count.textContent='No se pudo cargar el listado';list.textContent=e.message}
}
