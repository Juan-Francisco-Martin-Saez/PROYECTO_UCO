# UCO Sa Pobla 2.0 — Prototipo visual 0.2

Abre `public/index.html` mediante Live Server (VS Code) o un servidor local.

## Recursos gráficos
Todos los recursos de imagen están guardados en `public/img/` y se cargan localmente, sin dependencias de imágenes externas:
- `uco-logo.svg`: logotipo oficial aportado por el usuario, sin modificar.
- `hero-hortalizas.svg`: composición vectorial original de verduras.
- `categoria-frescos.svg`, `categoria-preparados.svg`, `categoria-congelados.svg`: ilustraciones vectoriales originales de muestra.

**Importante:** Las imágenes son ilustraciones originales de demostración, NO fotografías obtenidas de UCO o bancos de imágenes. Se podrán sustituir por fotografías autorizadas más adelante.

La paleta toma el azul marino `#232f5d` del SVG oficial. Tipografías Nunito y Nunito Sans (Google Fonts; con alternativas locales).

Los enlaces de categorías llevan provisionalmente al catálogo existente de UCO. No hay aún motor de pedidos, login ni SQLite activo. El directorio `private/` debe quedar fuera de la raíz pública al desplegar.
