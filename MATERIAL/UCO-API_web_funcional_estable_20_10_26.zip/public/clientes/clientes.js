import {createOrderService} from '../services/order-service.js';
import {createCartService} from '../services/cart-service.js';
import './components/cart-elements.js';
import {createClientServices} from '../services/client-services.js';
import './components/views.js';
import './components/catalog-elements.js';
const app=document.querySelector('#app');let csrf='',customer=null,page=1,query='';const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const services=createClientServices(()=>csrf),request=services.request,cart=createCartService(()=>csrf),orders=createOrderService(()=>csrf);
let reservationEnds=0,reservationId=null,reservationInterval=null;
function reservationClock(){
 const el=document.querySelector('#cart-view .uco-reservation-status');if(!el)return;
 if(!reservationEnds){el.replaceChildren();return;}
 const seconds=Math.max(0,Math.ceil(reservationEnds-Date.now()/1000));
 if(!seconds){reservationEnds=0;reservationId=null;el.innerHTML='<div class="uco-reservation-expired">La reserva ha caducado. Comprueba nuevamente la disponibilidad antes de continuar.</div>';return;}
 const mm=String(Math.floor(seconds/60)).padStart(2,'0'),ss=String(seconds%60).padStart(2,'0');
 el.innerHTML=`<div class="uco-reservation-banner"><div class="uco-reservation-description"><span class="uco-reservation-label">RESERVA ACTIVA</span><strong>Productos reservados</strong><small>Tiempo restante para completar el pedido</small></div><time class="uco-reservation-timer" aria-label="${mm} minutos y ${ss} segundos">${mm}:${ss}</time></div>`;
}
async function syncReservation(){
 if(!customer)return;
 try{const d=await orders.status();const active=(d.orders||[]).find(o=>o.status==='reserved'&&Number(o.expires_at)>Date.now()/1000);
 reservationEnds=active?Number(active.expires_at):0;reservationId=active?active.id:null;reservationClock();
 }catch(e){console.warn('No se pudo consultar la reserva',e);}
}
function startReservationClock(){if(reservationInterval)clearInterval(reservationInterval);reservationInterval=setInterval(reservationClock,1000);}
async function refreshCart(){const d=await cart.list();document.querySelector('#cart-count').textContent=d.items.reduce((a,i)=>a+i.quantity,0);document.querySelector('#cart-view').renderCart(d);reservationClock()}
async function cartAction(fn){try{await fn();await refreshCart()}catch(e){alert(e.details?.available!==undefined?`${e.message}. Disponibles: ${e.details.available}`:e.message);await refreshCart().catch(()=>{})}}
function login(){app.innerHTML=`<uco-client-login></uco-client-login>`;document.querySelector('#register').onclick=register;document.querySelector('#login-form').onsubmit=async e=>{e.preventDefault();try{const d=await request('login',{method:'POST',body:new FormData(e.currentTarget)});csrf=d.csrf;customer=d.customer;panel()}catch(err){document.querySelector('#error').textContent=err.message}}}
function register(){app.innerHTML=`<uco-client-register></uco-client-register>`;document.querySelector('#back-login').onclick=login;document.querySelector('#register-form').onsubmit=async e=>{e.preventDefault();const form=e.currentTarget,button=form.querySelector('[type=submit]'),error=document.querySelector('#error');error.textContent='';button.disabled=true;try{const data=await request('register',{method:'POST',body:new FormData(form)});login();const note=document.querySelector('#error');note.style.color='hsl(109 52% 25%)';note.textContent=data.message}catch(err){error.textContent=err.message}finally{button.disabled=false}}}
let cartReturnFocus=null;
function closeCart(){const el=document.querySelector('#cart-view');if(el)el.hidden=true;document.body.classList.remove('uco-cart-open');if(cartReturnFocus?.isConnected)cartReturnFocus.focus({preventScroll:true});cartReturnFocus=null;}
function openCart(){const el=document.querySelector('#cart-view');if(!el)return;cartReturnFocus=document.activeElement;el.hidden=false;document.body.classList.add('uco-cart-open');refreshCart().then(syncReservation).catch(e=>{const m=el.querySelector('.uco-cart-message');if(m)m.textContent=e.message});el.querySelector('.uco-cart-close')?.focus({preventScroll:true});}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!document.querySelector('#cart-view')?.hidden)closeCart();});
function panel(){startReservationClock();app.innerHTML=`<uco-client-panel></uco-client-panel>`;document.querySelector('#customer-name').textContent=customer.username||customer.company||'cliente';document.querySelector('#logout').onclick=async()=>{try{await request('logout',{method:'POST'})}finally{csrf='';customer=null;reservationEnds=0;reservationId=null;closeCart();login()}};document.querySelector('#password').onclick=changePassword;document.querySelector('#cart-toggle').onclick=()=>{const el=document.querySelector('#cart-view');if(el.hidden)openCart();else closeCart();};function showCheckoutNotice(message){
 const panel=document.querySelector('#cart-view .uco-cart-panel');
 if(!panel)return;
 panel.classList.remove('uco-cart-checkout-active');
 const checkout=panel.querySelector('.uco-checkout-view');
 if(checkout)checkout.replaceChildren();
 const footer=panel.querySelector('.uco-cart-footer');
 if(!footer)return;
 let notice=footer.querySelector('.uco-checkout-notice');
 if(!notice){notice=document.createElement('p');notice.className='uco-checkout-notice';notice.setAttribute('role','status');footer.append(notice);}
 notice.textContent=message;
}
document.querySelector('#cart-view').onclick=async e=>{if(e.target.closest('[data-order-checkout]')){document.querySelector('#cart-view .uco-checkout-notice')?.remove();
 const panel=document.querySelector('#cart-view .uco-cart-panel');
 let layout=panel.querySelector('.uco-cart-layout');
 if(!layout){
  layout=document.createElement('div');layout.className='uco-cart-layout';
  const left=document.createElement('div');left.className='uco-cart-left';
  const right=document.createElement('div');right.className='uco-cart-right';
  const content=panel.querySelector('.uco-cart-content'),footer=panel.querySelector('.uco-cart-footer');
  panel.append(layout);layout.append(left,right);left.append(content,footer);
  right.append(footer.querySelector('.uco-checkout-view'));
 }
 panel.classList.add('uco-cart-checkout-active');
 const out=panel.querySelector('.uco-checkout-view');out.textContent='Comprobando existencias y condiciones del pedido…';try{const preview=await orders.preview();if(!preview.valid){showCheckoutNotice(preview.issues.length?preview.issues.map(i=>`${i.name}: solicitadas ${i.requested}, disponibles ${i.available}`).join(' · '):'El carrito está vacío.');return;}const methods=await orders.methods();const format=c=>(c/100).toLocaleString('es-ES',{style:'currency',currency:'EUR'});out.innerHTML=`<section class="uco-checkout-box"><div class="uco-checkout-title"><span class="uco-checkout-kicker">REVISIÓN DE COMPRA</span><h3>Resumen del pedido</h3><p>Comprueba los detalles antes de reservar tus productos.</p></div><div class="uco-checkout-metrics"><div><span>Referencias</span><strong>${preview.items.length}</strong></div><div><span>Subtotal provisional</span><strong>${format(preview.subtotal_cents)}</strong></div></div><div class="uco-checkout-info"><strong>Importe pendiente de confirmar</strong><p>Los impuestos y la entrega se calcularán en el cierre definitivo.<br>En esta fase no se realizará ningún cobro.</p></div><div class="uco-checkout-methods"><h4>Formas de pago previstas</h4><p>${methods.methods.map(m=>m.name).join(' · ')}</p></div><form class="uco-delivery-form" id="uco-delivery-form"><h4>Datos de entrega</h4><p>Indica dónde quieres recibir el pedido. Podrás modificarlos antes de la confirmación definitiva.</p><div class="uco-delivery-grid"><label>Persona de contacto<input name="contact" maxlength="100" autocomplete="name" required></label><label>Teléfono<input name="phone" maxlength="35" autocomplete="tel" required></label><label class="wide">Dirección de entrega<input name="address" maxlength="180" autocomplete="street-address" required></label><label>Código postal<input name="postal_code" maxlength="12" autocomplete="postal-code" required></label><label>Localidad<input name="city" maxlength="90" autocomplete="address-level2" required></label><label class="wide">Provincia<input name="province" maxlength="90" autocomplete="address-level1" required></label><label class="wide">Observaciones<textarea name="notes" maxlength="500" rows="2"></textarea></label></div><p class="uco-delivery-feedback" role="status" aria-live="polite"></p></form><p class="uco-checkout-hint">Al continuar, reservaremos tus existencias durante <strong>10 minutos</strong>.</p><button type="button" class="primary" data-order-reserve>Reservar existencias</button><button type="button" class="secondary" data-order-back>Volver al carrito</button></section>`;try{const saved=await fetch('../api/checkout.php',{credentials:'same-origin',cache:'no-store'});if(saved.ok){const data=await saved.json();if(data.details){const form=out.querySelector('#uco-delivery-form');for(const [key,value] of Object.entries(data.details)){const field=form.elements.namedItem(key);if(field)field.value=value??'';}}}}catch(error){console.warn('No se pudieron recuperar los datos de entrega',error)}}catch(err){showCheckoutNotice(err.message);}return;}if(e.target.closest('[data-order-back]')){document.querySelector('.uco-checkout-view').replaceChildren();document.querySelector('#cart-view [data-payment-open]')?.remove();document.querySelector('#cart-view .uco-cart-panel')?.classList.remove('uco-cart-checkout-active');return;}if(e.target.closest('[data-order-reserve]')){const out=document.querySelector('.uco-checkout-view');try{const delivery=out.querySelector('#uco-delivery-form');if(delivery){if(!delivery.reportValidity())return;const response=await fetch('../api/checkout.php',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'X-CSRF-Token':csrf},body:new FormData(delivery)});const data=await response.json();if(!response.ok)throw Error(data.error||'No se pudieron guardar los datos de entrega');}const r=await orders.reserve();reservationEnds=Number(r.expires_at);reservationId=r.order_id;reservationClock();showCheckoutNotice('Existencias reservadas correctamente. Todavía no se ha confirmado ni cobrado el pedido.');
 const footer=document.querySelector('#cart-view .uco-cart-footer');
 if(footer){footer.querySelector('[data-payment-open]')?.remove();const next=document.createElement('button');next.type='button';next.className='uco-payment-open';next.dataset.paymentOpen='';next.textContent='Elegir forma de pago';footer.append(next);}
}catch(err){showCheckoutNotice(err.details?.issues?.length?err.details.issues.map(i=>`${i.name}: disponibles ${i.available}`).join(' · '):err.message);}return;}if(e.target.closest('[data-payment-open]')){
 const panel=document.querySelector('#cart-view .uco-cart-panel');
 const layout=panel.querySelector('.uco-cart-layout');
 const out=panel.querySelector('.uco-checkout-view');
 if(!layout||!out)return;
 panel.classList.add('uco-cart-checkout-active');
 out.innerHTML='<section class="uco-payment-step"><span class="uco-checkout-kicker">SIGUIENTE PASO</span><h3>Forma de pago</h3><p>Selecciona cómo deseas pagar. Ningún cobro se realizará todavía.</p><div class="uco-payment-loading">Comprobando la reserva y los datos de entrega…</div></section>';
 try{
  const r=await fetch('../api/payment-selection.php',{credentials:'same-origin',cache:'no-store'});
  const data=await r.json();if(!r.ok)throw Error(data.error||'No se pudieron consultar los pagos');
  const step=out.querySelector('.uco-payment-step');
  step.querySelector('.uco-payment-loading').remove();
  const labels={redsys:'Tarjeta bancaria · TPV multibanco',transfer:'Transferencia bancaria',paypal:'PayPal',bizum:'Bizum'};
  const descriptions={redsys:'Pago seguro con el TPV bancario contratado por UCO',transfer:'Instrucciones bancarias al confirmar el pedido',paypal:'Pago mediante una cuenta PayPal',bizum:'Pago móvil con Bizum a través del TPV habilitado'};
  const form=document.createElement('form');form.className='uco-payment-form';
  for(const key of ['redsys','transfer','paypal','bizum']){
   const label=document.createElement('label');label.className='uco-payment-option';
   const input=document.createElement('input');input.type='radio';input.name='payment_method';input.value=key;input.required=true;
   if(key===data.selected_method)input.checked=true;
   const text=document.createElement('span'),strong=document.createElement('strong'),small=document.createElement('small');
   strong.textContent=labels[key];small.textContent=descriptions[key];text.append(strong,small);label.append(input,text);form.append(label);
  }
  const msg=document.createElement('p');msg.className='uco-payment-feedback';msg.setAttribute('role','status');
  const button=document.createElement('button');button.type='submit';button.className='uco-payment-save';button.textContent='Guardar forma de pago';
  form.append(button,msg);step.append(form);
  const back=document.createElement('button');back.type='button';back.className='uco-payment-back';back.dataset.orderBack='';back.textContent='Volver al carrito';step.append(back);
  form.onsubmit=async ev=>{
   ev.preventDefault();button.disabled=true;msg.textContent='Guardando selección…';
   try{
    const fd=new FormData(form);
    const resp=await fetch('../api/payment-selection.php',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'X-CSRF-Token':csrf},body:fd});
    const result=await resp.json();if(!resp.ok)throw Error(result.error||'No se pudo guardar el método');
    msg.textContent='Forma de pago guardada. La confirmación definitiva y el cobro se habilitarán cuando estén configurados los impuestos, el transporte y la pasarela.';
   }catch(err){msg.textContent=err.message}finally{button.disabled=false}
  };
 }catch(err){out.querySelector('.uco-payment-step').innerHTML='<h3>Forma de pago</h3><p class="uco-payment-feedback"></p>';out.querySelector('.uco-payment-feedback').textContent=err.message;}
 return;
}
if(e.target.closest('[data-order-preview]')){const out=document.querySelector('.uco-order-feedback');out.textContent='Comprobando existencias…';orders.preview().then(d=>{out.textContent=d.valid?'Todos los productos están disponibles en este momento. Se verificarán de nuevo antes del cobro.':d.issues.length?d.issues.map(i=>`${i.name}: solicitadas ${i.requested}, disponibles ${i.available}${i.reason==='sin_precio'?' (sin precio)':''}`).join(' · '):'El carrito está vacío.'}).catch(err=>{out.textContent=err.message});return;}if(e.target.closest('[data-cart-close]')){closeCart();return;}const b=e.target.closest('[data-cart-remove]');if(b)cartAction(()=>cart.set(b.dataset.cartRemove,0))};document.querySelector('#cart-view').onchange=e=>{const input=e.target.closest('[data-cart-quantity]');if(input)cartAction(()=>cart.set(input.dataset.cartQuantity,input.value))};document.querySelector('uco-client-product-list').onclick=e=>{const b=e.target.closest('[data-cart-add]');if(!b)return;cartAction(async()=>{const d=await cart.list();const existing=d.items.find(i=>i.product_id===Number(b.dataset.cartAdd));await cart.set(b.dataset.cartAdd,(existing?.quantity||0)+1)});};refreshCart().catch(()=>{});let t;document.querySelector('#q').oninput=e=>{clearTimeout(t);t=setTimeout(()=>{query=e.target.value.trim();page=1;load()},250)};document.querySelector('#prev').onclick=()=>{page--;load()};document.querySelector('#next').onclick=()=>{page++;load()};load()}
async function load(){const msg=document.querySelector('#msg');msg.textContent='Cargando productos…';try{const d=await services.catalog.list({page,q:query});msg.textContent='';document.querySelector('#count').textContent=`${d.total} productos`;document.querySelector('uco-client-product-list').renderProducts(d.products,esc);document.querySelector('#paging').textContent=`Página ${d.page} de ${Math.max(1,Math.ceil(d.total/d.limit))}`;document.querySelector('#prev').disabled=d.page<=1;document.querySelector('#next').disabled=d.page*d.limit>=d.total}catch(err){msg.textContent=err.message}}
function changePassword(){const d=document.createElement('dialog');d.className='password-dialog';d.append(document.createElement('uco-client-password-content'));document.body.append(d);d.querySelector('#close').onclick=d.querySelector('#cancel').onclick=()=>d.close();d.addEventListener('close',()=>d.remove());d.querySelector('form').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.currentTarget);if(f.get('new_password')!==f.get('confirm')){d.querySelector('#err').textContent='Las contraseñas no coinciden';return}try{await request('change_password',{method:'POST',body:f});d.close();alert('Contraseña actualizada.')}catch(err){d.querySelector('#err').textContent=err.message}};d.showModal()}
(async()=>{try{const d=await request('session');if(d.authenticated){csrf=d.csrf;customer=d.customer;panel()}else login()}catch(err){login()}})();
