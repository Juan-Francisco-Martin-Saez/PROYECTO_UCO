# UCO Sa Pobla 2.0 — Versión 0.6

Base de la versión 0.5, con ajustes focalizados de navegación y fotografías.

- Anclas Inicio, Familias, Selección, Sobre UCO, Pedidos y Contacto: desplazamiento calculado según la altura REAL de la cabecera fija, incluso al cambiar de dispositivo. La sección comienza justo debajo de la cabecera.
- Menú de escritorio más grande; navegación activa, hover e indicador adaptados al menú móvil corporativo.
- Slider con imágenes a sangre (`object-fit: cover`) ocupando toda la superficie, sin máscaras ni bandas. Puede recortarse parte de la foto para mantener el formato sin deformarla.
- Se conservan el contacto, pedidos de muestra, imágenes locales y estructura de Web Components de la versión anterior.
- Formulario de contacto de demostración: abre el cliente de correo mediante `mailto:`; todavía no envía al servidor.

Abrir `public/index.html` mediante Live Server o servir `public/` con un servidor HTTP local.

## Versión 0.7
Formulario con nombre y apellidos separados, correo y teléfono en segunda fila. Esquinas corporativas curvas superior izquierda e inferior derecha en fotografías, formulario, mapa, logo del pie y navegación; se conservan tamaños y colores hover.

## v0.8 — Botones con geometría corporativa
Todos los botones (CTA, formulario, slider, indicadores, menú hamburguesa móvil/tableta y controles compactos) usan curvas exclusivamente en la esquina superior izquierda y la inferior derecha. Se mantienen los tamaños, colores, transparencias y comportamientos de v0.7.


## Versión 0.9
- Selector de idioma ES/CA/EN con banderas; selección visual, traducciones pendientes.
- Selector compacto en barra superior de escritorio; dentro del menú hamburguesa en móvil y tableta.
- Textos de la barra superior agrupados a la izquierda en escritorio y centrados en pantallas pequeñas.
- Footer informativo centrado en móvil y tableta, sin alterar formulario ni mapa.
- Ajustes específicos del espacio inicial de Familias y Selección en móvil y tableta, respetando cabecera fija.


## Versión 1.1
- Botones de acción sin flechas decorativas; textos más visibles, negrita y centrados.
- Flechas del carrusel conservadas porque son controles de navegación funcionales.
- Icono en las cuatro tarjetas de familias: `img/uco-logo-blanco-calado.svg`, generado a partir de los trazados vectoriales EXACTOS del logotipo original; blanco en lugar del fondo azul, con letras y detalles originales perforados (transparentes).
- Logotipo corporativo original conservado sin modificaciones.


## Versión 1.2
- En móvil/tableta (hasta 820 px), «Explorar catálogo» pasa al menú hamburguesa, después de los enlaces y antes del selector de idiomas.
- Banda verde animada de derecha hacia la izquierda visualmente? No: el contenido avanza **de izquierda a derecha**, en bucle continuo, con 16 términos relacionados con UCO.
- Animación desactivada si el dispositivo solicita movimiento reducido; se permite desplazamiento manual.
- Se conservan el diseño de escritorio y las funcionalidades existentes.


## Versión 1.3 — Primera fase de catálogo dinámico
- Se ha conservado íntegramente el `uco-footer.js` actualizado por el usuario.
- El catálogo de demostración ahora se obtiene mediante la API PHP de solo lectura sobre SQLite. Incluye búsqueda, filtros de familias y paginación.
- La base está en `private/database/catalogo.sqlite`, fuera de `public/`. No publicar nunca `private/` como raíz web.
- La API está en `public/api/index.php?action=catalog`; acepta `q`, `category`, `page`, `limit` (máximo 24).
- Si se abre con Live Server sin PHP, el componente usa `public/data/catalog-demo.json` como **fallback de demostración**, sin sincronización ni persistencia.
- Para probar PHP: `cd public && php -S 127.0.0.1:8000`; abrir `http://127.0.0.1:8000/`. Requiere extensión PHP `pdo_sqlite`.
- Los 16 productos y las fotografías son **ejemplos ilustrativos**, no catálogo comercial confirmado. No hay precios, pedidos ni panel de administración.
- Las tablas `product_formats` y `sync_log` anticipan fases posteriores sin activar integración GESCOM.
- Siguiente fase: validar categorías y referencias reales, diseñar administración autenticada, formatos, fotografías y tarifas por cliente.
