# UCO Sa Pobla 2.0 - Version 1.7: actualizador seguro para Windows

## Antes de actualizar

Esta entrega conserva el codigo y el diseño de la version 1.6; la novedad es el actualizador PowerShell. No borres ni sobrescribas manualmente tu instalacion.

1. Descomprime este ZIP en una carpeta distinta de `UCO-API` (por ejemplo, `GIT/UCO-v1.7`).
2. Deten el servidor PHP con Ctrl+C. **Es obligatorio para copiar SQLite de forma consistente**.
3. Abre PowerShell en la carpeta descomprimida y ejecuta `powershell -NoProfile -ExecutionPolicy Bypass -File .\actualizar.ps1`.
4. El actualizador buscara `Documents/GIT/UCO-API`. Si no existe, pedira la ruta.
5. Confirma escribiendo `SI` cuando se solicite. Espera a que indique que ha terminado.
6. Vuelve a arrancar PHP desde `UCO-API/public` y comprueba `http://localhost:8000/admin/`.

Tambien puedes indicar la instalacion explicitamente: `powershell -NoProfile -ExecutionPolicy Bypass -File .\actualizar.ps1 -Destino "C:\ruta\UCO-API"`.

## Copias y datos

Antes de tocar nada crea `UCO-Backups/backup-AAAAmmdd-HHMMSS.zip` **junto a la carpeta UCO-API**, nunca dentro. La copia contiene la instalacion anterior completa, incluida `private/` y las imagenes de usuario y producto. Verifica que el ZIP contenga los archivos esenciales y la base de datos, si existe. Si la copia falla, cancela la actualizacion.

Durante la actualizacion, la carpeta `private/` permanece intacta; por tanto, se conservan los usuarios y hashes de contrasenas de SQLite, los productos y el stock. Las carpetas de imagenes cargadas dentro de `public/img/` se transfieren a la nueva version. Los archivos del programa se reemplazan con la nueva entrega. No se borra ninguna copia de seguridad automaticamente.

## Precauciones

- Esta version no modifica la estructura SQLite ni migra todavia las fotografias a `private/uploads`. Para poder sustituir todo `public/` de forma segura, **usa siempre el script**, no el borrado manual.
- El servidor PHP debe estar detenido durante la actualizacion. Evita editar datos durante la copia.
- Si el actualizador encuentra carpetas `.uco17-staging` o `.uco17-rollback`, se detiene para evitar pisar una actualizacion incompleta.
- En caso de fallo al sustituir `public`, intenta restaurar la version anterior. El respaldo ZIP externo permite recuperacion manual adicional.
- No se incluyen contrasenas en texto plano ni se crean usuarios nuevos durante la actualizacion.
- Para instalaciones nuevas, la configuracion del primer administrador sigue el procedimiento documentado en v1.5/v1.6.
