﻿param([string]$Destino = '', [switch]$NoConfirmar)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourcePublic = Join-Path $base 'public'
$sourcePrivate = Join-Path $base 'private'
function Fail([string]$message) { throw $message }
function IsProject([string]$path) {
    return (Test-Path (Join-Path $path 'public\index.html') -PathType Leaf) -and (Test-Path (Join-Path $path 'public\api\admin.php') -PathType Leaf)
}
function CopyTree([string]$src,[string]$dst) {
    if (Test-Path $dst) { Remove-Item -LiteralPath $dst -Recurse -Force }
    Copy-Item -LiteralPath $src -Destination $dst -Recurse -Force
}
function CopyPreserved([string]$relative,[string]$from,[string]$to) {
    $src=Join-Path $from $relative
    if (Test-Path $src -PathType Container) {
        $dst=Join-Path $to $relative
        $parent=Split-Path -Parent $dst
        if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
        if (Test-Path $dst) { Remove-Item -LiteralPath $dst -Recurse -Force }
        Copy-Item -LiteralPath $src -Destination $dst -Recurse -Force
    }
}
try {
    Write-Host "`nUCO Sa Pobla 2.0 - Actualizador v1.7" -ForegroundColor Green
    if (-not (Test-Path $sourcePublic) -or -not (Test-Path $sourcePrivate)) { Fail 'El paquete de actualizacion esta incompleto.' }
    if (-not $Destino) {
        $candidates=@((Join-Path $env:USERPROFILE 'Documents\GIT\UCO-API'), (Join-Path (Split-Path $base -Parent) 'UCO-API'))
        foreach ($c in $candidates) { if (IsProject $c) { $Destino=$c; break } }
    }
    while (-not $Destino -or -not (IsProject $Destino)) {
        $Destino=Read-Host 'Introduce la ruta completa de la carpeta UCO-API existente'
        $Destino=$Destino.Trim('"').Trim()
        if (-not $Destino) { Fail 'Actualizacion cancelada: no se ha seleccionado destino.' }
        if (-not (IsProject $Destino)) { Write-Warning 'La ruta no contiene una instalacion UCO valida.' }
    }
    $Destino=(Resolve-Path -LiteralPath $Destino).Path
    $base=(Resolve-Path -LiteralPath $base).Path
    if ($Destino -eq $base -or $Destino.StartsWith($base+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) -or $base.StartsWith($Destino+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { Fail 'La actualizacion debe estar descomprimida fuera de la instalacion actual.' }
    $parent=Split-Path -Parent $Destino
    $backups=Join-Path $parent 'UCO-Backups'
    $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
    $backup=Join-Path $backups "backup-$stamp.zip"
    $oldPublic=Join-Path $Destino 'public'
    $oldPrivate=Join-Path $Destino 'private'
    $staging=Join-Path $Destino '.uco17-staging'
    $rollback=Join-Path $Destino '.uco17-rollback'
    if ((Test-Path $staging) -or (Test-Path $rollback)) { Fail 'Hay una actualizacion anterior pendiente. Revisa las carpetas .uco17-staging y .uco17-rollback antes de continuar.' }
    Write-Host "Instalacion: $Destino"
    Write-Host "Respaldo: $backup"
    Write-Host 'IMPORTANTE: detén el servidor PHP (Ctrl+C) antes de continuar para garantizar una copia consistente de SQLite.' -ForegroundColor Yellow
    if (-not $NoConfirmar) {
        $answer=Read-Host '¿Has detenido PHP y deseas continuar? (SI para confirmar)'
        if ($answer -cne 'SI') { Fail 'Actualizacion cancelada por el usuario.' }
    }
    New-Item -ItemType Directory -Path $backups -Force | Out-Null
    # Snapshot in an isolated temporary directory, outside installation.
    $temp=Join-Path $backups ('.snapshot-'+$stamp)
    New-Item -ItemType Directory -Path $temp -Force | Out-Null
    try {
        Copy-Item -LiteralPath $oldPublic -Destination (Join-Path $temp 'public') -Recurse -Force
        if (Test-Path $oldPrivate) { Copy-Item -LiteralPath $oldPrivate -Destination (Join-Path $temp 'private') -Recurse -Force }
        Compress-Archive -Path (Join-Path $temp '*') -DestinationPath $backup -CompressionLevel Optimal -Force
        Add-Type -AssemblyName System.IO.Compression
        $z=[IO.Compression.ZipFile]::OpenRead($backup)
        try {
            if ($z.Entries.Count -lt 5 -or -not ($z.Entries | Where-Object FullName -eq 'public/index.html') -or -not ($z.Entries | Where-Object FullName -eq 'public/api/admin.php')) { Fail 'El respaldo ZIP no supera la comprobacion de integridad.' }
            if ((Test-Path (Join-Path $oldPrivate 'database\catalogo.sqlite')) -and -not ($z.Entries | Where-Object FullName -eq 'private/database/catalogo.sqlite')) { Fail 'Falta la base de datos en el respaldo.' }
        } finally { $z.Dispose() }
    } finally { if (Test-Path $temp) { Remove-Item -LiteralPath $temp -Recurse -Force } }
    Write-Host 'Respaldo creado y verificado.' -ForegroundColor Green
    CopyTree $sourcePublic $staging
    CopyPreserved 'img\productos' $oldPublic $staging
    CopyPreserved 'img\usuarios' $oldPublic $staging
    # Preserve any user uploads under img in case later releases introduce more directories.
    $images=Join-Path $oldPublic 'img'
    if (Test-Path $images) {
        Get-ChildItem -LiteralPath $images -Directory | ForEach-Object { CopyPreserved ('img\'+$_.Name) $oldPublic $staging }
    }
    $swapped=$false
    try {
        Rename-Item -LiteralPath $oldPublic -NewName '.uco17-rollback'
        try { Rename-Item -LiteralPath $staging -NewName 'public'; $swapped=$true }
        catch { Rename-Item -LiteralPath $rollback -NewName 'public'; throw }
        if (-not (IsProject $Destino)) { Fail 'La nueva instalacion no supera la verificacion de archivos.' }
        if (Test-Path $oldPrivate) {
            if (-not (Test-Path (Join-Path $oldPrivate 'database\catalogo.sqlite'))) { Fail 'No se encuentra la base de datos existente.' }
        } else {
            CopyTree $sourcePrivate $oldPrivate
        }
        Remove-Item -LiteralPath $rollback -Recurse -Force
        Write-Host "`nActualizacion 1.7 completada correctamente." -ForegroundColor Green
        Write-Host 'Los usuarios, contrasenas, productos, stock e imagenes se han conservado.'
        Write-Host "Respaldo: $backup"
        Write-Host 'Ahora puedes volver a iniciar PHP: C:\php\php.exe -S localhost:8000'
    } catch {
        Write-Warning ('Error durante la instalacion: '+$_.Exception.Message)
        if ($swapped -and (Test-Path $rollback)) {
            if (Test-Path $oldPublic) { Remove-Item -LiteralPath $oldPublic -Recurse -Force }
            Rename-Item -LiteralPath $rollback -NewName 'public'
            Write-Warning 'Se ha restaurado la version anterior.'
        }
        throw
    }
} catch {
    Write-Host ('ERROR: '+$_.Exception.Message) -ForegroundColor Red
    exit 1
}
