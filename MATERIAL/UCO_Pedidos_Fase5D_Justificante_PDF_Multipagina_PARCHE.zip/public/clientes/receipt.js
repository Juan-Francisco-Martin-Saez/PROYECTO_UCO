/* UCO 5D — justificante exclusivamente de operaciones simuladas aprobadas. */
const money=n=>(Number(n)/100).toLocaleString('es-ES',{style:'currency',currency:'EUR'});
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const methods={redsys:'Tarjeta bancaria (simulada)',paypal:'PayPal (simulado)',bizum:'Bizum (simulado)',transfer:'Transferencia (simulada)'};
let loader;
async function loadPdf(){
 if(window.jspdf?.jsPDF)return window.jspdf.jsPDF;
 if(!loader)loader=new Promise((resolve,reject)=>{
  const script=document.createElement('script');script.src='https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.2/jspdf.umd.min.js';
  script.crossOrigin='anonymous';script.onload=()=>resolve(window.jspdf?.jsPDF);script.onerror=()=>reject(Error('No se pudo cargar el generador PDF. Comprueba la conexión.'));document.head.append(script);
 });
 const result=await loader;if(!result)throw Error('Generador PDF no disponible');return result;
}
async function imageData(src){
 if(!src)return null;
 try{
  const response=await fetch(src,{credentials:'same-origin'});if(!response.ok)return null;
  const blob=await response.blob();const bmp=await createImageBitmap(blob);
  const canvas=document.createElement('canvas');canvas.width=150;canvas.height=150;
  const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,150,150);
  const ratio=Math.min(140/bmp.width,140/bmp.height);ctx.drawImage(bmp,(150-bmp.width*ratio)/2,(150-bmp.height*ratio)/2,bmp.width*ratio,bmp.height*ratio);
  bmp.close();return canvas.toDataURL('image/jpeg',.8);
 }catch{return null;}
}
async function buildPdf(d){
 const PDF=await loadPdf();const pdf=new PDF({orientation:'portrait',unit:'mm',format:'a4',compress:true});
 const W=210,H=297,L=15,R=195;let y=0,page=0;
 const header=()=>{
  page++;pdf.setFillColor(35,47,93);pdf.rect(0,0,W,32,'F');
  pdf.setTextColor(255);pdf.setFont('helvetica','bold');pdf.setFontSize(19);pdf.text('UCO',L,16);
  pdf.setFontSize(10);pdf.text('JUSTIFICANTE DE PEDIDO',R,13,{align:'right'});
  pdf.setFontSize(8);pdf.text('ENTORNO DE PRUEBAS - SIN COBRO REAL',R,20,{align:'right'});
  pdf.setTextColor(35,47,93);y=41;
 };
 const footer=()=>{
  pdf.setDrawColor(218,224,233);pdf.line(L,283,R,283);pdf.setTextColor(100,112,130);pdf.setFontSize(8);
  pdf.text('Documento de prueba - No es factura ni justificante bancario',L,289);
  pdf.text(String(page),R,289,{align:'right'});
 };
 const next=(needed)=>{if(y+needed>275){footer();pdf.addPage();header();}};
 const heading=t=>{next(15);pdf.setTextColor(35,47,93);pdf.setFont('helvetica','bold');pdf.setFontSize(11);pdf.text(t,L,y+5);y+=12;};
 const line=(label,value)=>{next(9);pdf.setFont('helvetica','normal');pdf.setFontSize(9);pdf.setTextColor(50,60,78);pdf.text(String(label),L,y);pdf.setFont('helvetica','bold');pdf.text(String(value),R,y,{align:'right'});y+=8;};
 header();heading('Datos del pedido');line('Numero de pedido','PED-'+d.order_id);line('Referencia',d.reference);line('Fecha',d.created_at);
 heading('Datos de entrega');
 const address=d.delivery||{};
 for(const s of [address.contact,address.phone,address.address,[address.postal_code,address.city].filter(Boolean).join(' '),address.province,address.notes].filter(Boolean)){
  const wrapped=pdf.splitTextToSize(String(s),175);next(wrapped.length*5+2);pdf.setFont('helvetica','normal');pdf.setFontSize(9);pdf.text(wrapped,L,y);y+=wrapped.length*5+2;
 }
 heading('Productos');
 for(const item of d.items){
  const name=pdf.splitTextToSize(String(item.name),107);const h=Math.max(19,name.length*5+8);next(h);
  pdf.setDrawColor(228,233,239);pdf.roundedRect(L,y-3,180,h-2,2,2,'S');
  const img=await imageData(item.image);if(img)pdf.addImage(img,'JPEG',L+2,y-1,16,16);
  pdf.setFont('helvetica','bold');pdf.setFontSize(9);pdf.setTextColor(35,47,93);pdf.text(name,L+22,y+3);
  pdf.setFont('helvetica','normal');pdf.setFontSize(8);pdf.text(String(item.sku||'')+'  |  '+item.quantity+' x '+money(item.unit_price_cents),L+22,y+name.length*5+4);
  pdf.setFont('helvetica','bold');pdf.text(money(item.line_cents),R-3,y+6,{align:'right'});y+=h+2;
 }
 heading('Desglose economico');line('Subtotal',money(d.subtotal_cents));line('IVA',money(d.tax_cents));line('Transporte',money(d.shipping_cents));
 next(15);pdf.setFillColor(239,246,229);pdf.roundedRect(L,y-4,180,13,2,2,'F');pdf.setTextColor(35,47,93);pdf.setFontSize(12);pdf.setFont('helvetica','bold');pdf.text('TOTAL FINAL',L+3,y+4);pdf.text(money(d.total_cents),R-3,y+4,{align:'right'});y+=19;
 heading('Datos de la operacion simulada');line('Metodo',methods[d.method]||d.method);line('Resultado','APROBACION SIMULADA');line('Referencia',d.reference);line('Fecha de operacion',d.operation_at);
 next(15);pdf.setFontSize(9);pdf.setTextColor(130,65,30);pdf.text('OPERACION FICTICIA. NO ACREDITA NINGUN PAGO REAL.',L,y+5);footer();
 return pdf;
}
export async function openUcoReceipt(orderId){
 const r=await fetch('../api/order-receipt.php?order_id='+encodeURIComponent(orderId),{credentials:'same-origin',cache:'no-store'});
 const d=await r.json();if(!r.ok)throw Error(d.error||'No se pudo recuperar el justificante');
 const PDF=await buildPdf(d);const blob=PDF.output('blob');const url=URL.createObjectURL(blob);
 const dialog=document.createElement('dialog');dialog.className='uco-receipt-dialog';
 const head=document.createElement('header');head.className='uco-receipt-head';
 const title=document.createElement('strong');title.textContent='UCO · Justificante PED-'+d.order_id;
 const buttons=document.createElement('div');
 const download=document.createElement('a');download.href=url;download.download='UCO_Pedido_'+d.order_id+'_SIMULADO.pdf';download.textContent='Descargar PDF';
 const print=document.createElement('button');print.type='button';print.textContent='Imprimir';
 const close=document.createElement('button');close.type='button';close.textContent='Cerrar';
 buttons.append(download,print,close);head.append(title,buttons);
 const iframe=document.createElement('iframe');iframe.src=url;iframe.title='Vista previa del justificante PDF';dialog.append(head,iframe);document.body.append(dialog);
 const cleanup=()=>{dialog.close();dialog.remove();setTimeout(()=>URL.revokeObjectURL(url),30000)};
 close.onclick=cleanup;dialog.addEventListener('cancel',e=>{e.preventDefault();cleanup()});
 print.onclick=()=>{try{iframe.contentWindow?.print()}catch{window.open(url,'_blank','noopener')}};
 dialog.showModal();
}
