# UCO Sa Pobla 2.0 — Versión 0.6

Base de la versión 0.5, con ajustes focalizados de navegación y fotografías.

- Anclas Inicio, Familias, Selección, Sobre UCO, Pedidos y Contacto: desplazamiento calculado según la altura REAL de la cabecera fija, incluso al cambiar de dispositivo. La sección comienza justo debajo de la cabecera.
- Menú de escritorio más grande; navegación activa, hover e indicador adaptados al menú móvil corporativo.
- Slider con imágenes a sangre (`object-fit: cover`) ocupando toda la superficie, sin máscaras ni bandas. Puede recortarse parte de la foto para mantener el formato sin deformarla.
- Se conservan el contacto, pedidos de muestra, imágenes locales y estructura de Web Components de la versión anterior.
- Formulario de contacto de demostración: abre el cliente de correo mediante `mailto:`; todavía no envía al servidor.

Abrir `public/index.html` mediante Live Server o servir `public/` con un servidor HTTP local.

## Versión 0.7
Formulario con nombre y apellidos separados, correo y teléfono en segunda fila. Esquinas corporativas curvas superior izquierda e inferior derecha en fotografías, formulario, mapa, logo del pie y navegación; se conservan tamaños y colores hover.

## v0.8 — Botones con geometría corporativa
Todos los botones (CTA, formulario, slider, indicadores, menú hamburguesa móvil/tableta y controles compactos) usan curvas exclusivamente en la esquina superior izquierda y la inferior derecha. Se mantienen los tamaños, colores, transparencias y comportamientos de v0.7.
