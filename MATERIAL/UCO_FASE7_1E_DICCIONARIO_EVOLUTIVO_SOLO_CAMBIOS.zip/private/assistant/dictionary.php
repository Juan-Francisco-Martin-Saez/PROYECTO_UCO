<?php
declare(strict_types=1);
function uco_norm(string $s):string {
 $s=mb_strtolower($s,'UTF-8');
 $s=strtr($s,['á'=>'a','é'=>'e','í'=>'i','ó'=>'o','ú'=>'u','ü'=>'u','ñ'=>'n']);
 return trim(preg_replace('/\s+/u',' ',preg_replace('/[^\p{L}\p{N}]+/u',' ',$s))??'');
}
function uco_stem(string $s):string {
 if(mb_strlen($s,'UTF-8')>4 && str_ends_with($s,'es'))return mb_substr($s,0,-2,'UTF-8');
 if(mb_strlen($s,'UTF-8')>3 && str_ends_with($s,'s'))return mb_substr($s,0,-1,'UTF-8');
 return $s;
}
function uco_dictionary(PDO $db):void {
 $db->exec('CREATE TABLE IF NOT EXISTS concepts (
 id INTEGER PRIMARY KEY, term TEXT NOT NULL UNIQUE, kind TEXT NOT NULL DEFAULT \'general\',
 origin TEXT NOT NULL DEFAULT \'manual\', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
 )');
 $db->exec('CREATE TABLE IF NOT EXISTS synonyms (
 alias TEXT PRIMARY KEY, concept_id INTEGER NOT NULL REFERENCES concepts(id), status TEXT NOT NULL DEFAULT \'approved\'
 CHECK(status IN (\'approved\',\'disabled\')), origin TEXT NOT NULL DEFAULT \'manual\'
 )');
 $db->exec('CREATE TABLE IF NOT EXISTS relations (
 source_id INTEGER NOT NULL REFERENCES concepts(id), target_id INTEGER NOT NULL REFERENCES concepts(id),
 relation TEXT NOT NULL, status TEXT NOT NULL DEFAULT \'approved\'
 CHECK(status IN (\'approved\',\'disabled\')), PRIMARY KEY(source_id,target_id,relation)
 )');
 $db->exec('CREATE TABLE IF NOT EXISTS intents (
 term TEXT PRIMARY KEY, intent TEXT NOT NULL, status TEXT NOT NULL DEFAULT \'approved\'
 CHECK(status IN (\'approved\',\'disabled\'))
 )');
 $db->exec('CREATE TABLE IF NOT EXISTS unknown_terms (
 term TEXT PRIMARY KEY, occurrences INTEGER NOT NULL DEFAULT 1, last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 status TEXT NOT NULL DEFAULT \'pending\' CHECK(status IN (\'pending\',\'ignored\',\'approved\'))
 )');
 $db->exec('CREATE TABLE IF NOT EXISTS dictionary_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL)');
 $seed=[
 'patata'=>['papa','papas'], 'croqueta'=>['croquetas','croqueton'],
 'tomate'=>['jitomate'], 'precio'=>['coste','importe','tarifa'],
 'factura'=>['recibo','comprobante','justificante'], 'pedido'=>['compra','encargo'],
 'envio'=>['entrega','transporte','transportista'], 'categoria'=>['familia','seccion'],
 'cliente'=>['comprador'], 'producto'=>['articulo'], 'ayuda'=>['asistencia']
 ];
 $put=$db->prepare('INSERT OR IGNORE INTO concepts(term,kind,origin) VALUES(?,\'general\',\'seed\')');
 $alias=$db->prepare('INSERT OR IGNORE INTO synonyms(alias,concept_id,origin) VALUES(?,?,\'seed\')');
 foreach($seed as $term=>$words){
  $put->execute([$term]);$id=(int)$db->query('SELECT id FROM concepts WHERE term='.$db->quote($term))->fetchColumn();
  foreach($words as $w)$alias->execute([uco_norm($w),$id]);
 }
 foreach(['price'=>['precio','cuanto','cuesta','vale'],'buy'=>['comprar','pedir','encargar','quiero'],'varieties'=>['tipos','clases','variedades'],'help'=>['como','donde','ayuda','explica']] as $intent=>$words){
  $stmt=$db->prepare('INSERT OR IGNORE INTO intents(term,intent) VALUES(?,?)');
  foreach($words as $w)$stmt->execute([$w,$intent]);
 }
}
function uco_expand(PDO $db,array $tokens):array {
 $aliases=[];$canonical=[];
 foreach($db->query("SELECT c.term,s.alias FROM synonyms s JOIN concepts c ON c.id=s.concept_id WHERE s.status='approved'") as $row){
  $aliases[$row['alias']]=$row['term'];
  $canonical[$row['term']][]=$row['alias'];
 }
 $expanded=[];
 foreach($tokens as $token){
  $canon=$aliases[$token]??$token;
  $expanded[$canon]=array_values(array_unique(array_merge([$canon],$canonical[$canon]??[])));
 }
 return $expanded;
}
