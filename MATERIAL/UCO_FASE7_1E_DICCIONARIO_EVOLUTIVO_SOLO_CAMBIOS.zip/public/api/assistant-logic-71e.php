<?php
declare(strict_types=1);
ini_set('display_errors','0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
function answer(array $data,int $code=200):never {
 http_response_code($code);echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;
}
if(($_SERVER['REQUEST_METHOD']??'')!=='GET')answer(['ok'=>false,'error'=>'Método no permitido'],405);
$q=trim((string)($_GET['q']??''));
if(mb_strlen($q,'UTF-8')>240)answer(['ok'=>false,'error'=>'Consulta demasiado larga'],400);
if(mb_strlen($q,'UTF-8')<2)answer(['ok'=>true,'items'=>[],'topics'=>[],'intent'=>'unknown','terms'=>[]]);
$private=dirname(__DIR__,2).'/private';
require_once $private.'/assistant/dictionary.php';
$normalized=uco_norm($q);
$stop=array_flip(explode(' ','hola buenas buenos dias tardes noches por favor gracias puedes podria podriais dime decir tienes teneis hay alguna algun unos unas una uno que cuales cual cuantos cuanto como donde son del los las para por con sobre este esta esto estos estas interes saber busco busca buscar mostrar muestra y o de el la lo en al a mi tu su se me es si no un'));
$tokens=[];
foreach(explode(' ',$normalized) as $w){
 if(mb_strlen($w,'UTF-8')<3||isset($stop[$w]))continue;
 $w=uco_stem($w);
 if(!in_array($w,$tokens,true))$tokens[]=$w;
}
$tokens=array_slice($tokens,0,12);
$topicMap=['catalogo'=>['catalogo','producto','articulo','familia','categoria'],
 'pedidos'=>['pedido','compra','encargo','envio','transportista','entrega'],
 'facturas'=>['factura','recibo','comprobante','justificante'],
 'clientes'=>['cliente','usuario','cuenta','historial'],
 'precios'=>['precio','tarifa','coste','importe','promocion'],
 'ayuda'=>['ayuda','funciona','instruccion','procedimiento']];
try{
 $catalog=$private.'/database/catalogo.sqlite';
 if(!is_file($catalog))throw new RuntimeException('Catálogo ausente');
 $db=new PDO('sqlite:'.$catalog,null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
 $db->exec('PRAGMA query_only=ON');
 $dictPath=$private.'/assistant/dictionary.sqlite';
 if(!is_dir(dirname($dictPath)))throw new RuntimeException('Carpeta de diccionario ausente');
 $dict=new PDO('sqlite:'.$dictPath,null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
 $dict->exec('PRAGMA busy_timeout=2000');
 uco_dictionary($dict);
 $expanded=uco_expand($dict,$tokens);
 $intent='availability';
 $intentStmt=$dict->prepare("SELECT intent FROM intents WHERE term=? AND status='approved'");
 foreach(explode(' ',$normalized) as $w){
  $intentStmt->execute([uco_norm($w)]);
  $v=$intentStmt->fetchColumn();
  if($v!==false){$intent=(string)$v;break;}
 }
 $topics=[];
 foreach($topicMap as $topic=>$words)foreach(array_keys($expanded) as $token){
  if(in_array($token,array_map('uco_stem',$words),true)){$topics[]=$topic;break;}
 }
 $rows=$db->query("SELECT p.id,p.name,p.description,p.unit,p.search_text,p.is_demo,p.stock,c.name AS category
 FROM products p LEFT JOIN categories c ON c.id=p.category_id
 WHERE p.active=1 AND (c.id IS NULL OR c.active=1)")->fetchAll();
 $found=[];$recognized=[];
 foreach($rows as $p){
  $name=uco_norm((string)$p['name']);$cat=uco_norm((string)($p['category']??''));
  $body=uco_norm(implode(' ',[$p['description']??'',$p['search_text']??'']));
  $score=0;$matched=0;
  foreach($expanded as $canon=>$variants){
   $best=0;
   foreach($variants as $variant){
    $needle=uco_stem($variant);if($needle==='')continue;
    if(str_contains($name,$needle))$best=max($best,8);
    elseif(str_contains($cat,$needle))$best=max($best,5);
    elseif(str_contains($body,$needle))$best=max($best,2);
   }
   if($best){$score+=$best;$matched++;$recognized[$canon]=true;}
  }
  if(count($expanded)>2&&$matched===1)$score-=2;
  if($score<=0)continue;
  $found[]=['id'=>(int)$p['id'],'name'=>$p['name'],'unit'=>$p['unit'],
   'category'=>$p['category'],'is_demo'=>(bool)$p['is_demo'],'score'=>$score,'matched'=>$matched];
 }
 usort($found,static fn($a,$b)=>($b['matched']<=>$a['matched'])?:($b['score']<=>$a['score'])?:($a['is_demo']<=>$b['is_demo'])?:strcmp($a['name'],$b['name']));
 // Register unknown vocabulary as suggestions only; no raw conversation is stored.
 // Restrict writes to 3 tokens per query, <= 40 chars and maximum 2000 entries.
 $pending=$dict->prepare("INSERT INTO unknown_terms(term) VALUES(?) ON CONFLICT(term) DO UPDATE SET occurrences=MIN(occurrences+1,100000),last_seen=CURRENT_TIMESTAMP WHERE status='pending'");
 $known=$dict->prepare('SELECT 1 FROM concepts WHERE term=? UNION SELECT 1 FROM synonyms WHERE alias=? LIMIT 1');
 $unknownCount=(int)$dict->query('SELECT COUNT(*) FROM unknown_terms')->fetchColumn();
 $new=0;
 foreach($tokens as $token){
  if(isset($recognized[$token])||isset($expanded[$token])&&count($expanded[$token])>1)continue;
  if(mb_strlen($token,'UTF-8')>40||preg_match('/\d/u',$token))continue;
  if(in_array($token,['pedido','factura','precio','cliente','producto','categoria','ayuda','catalogo'],true))continue;
  $known->execute([$token,$token]);if($known->fetchColumn())continue;
  if($unknownCount>=2000||$new>=3)break;
  try{$pending->execute([$token]);$new++;}catch(Throwable $ignored){/* no impact on search */}
 }
 answer(['ok'=>true,'intent'=>$intent,'terms'=>$tokens,'topics'=>$topics,
 'items'=>array_slice($found,0,12),'truncated'=>count($found)>12,
 'source'=>'active_catalog+approved_dictionary','count'=>count($found)]);
}catch(Throwable $e){
 error_log('[UCO assistant 7.1E] '.$e->getMessage());
 answer(['ok'=>false,'error'=>'No se puede consultar el catálogo en este momento'],503);
}
