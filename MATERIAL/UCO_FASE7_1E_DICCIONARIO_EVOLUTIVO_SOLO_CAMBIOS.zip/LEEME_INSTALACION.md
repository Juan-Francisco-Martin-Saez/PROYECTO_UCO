# UCO 7.1E — Diccionario evolutivo SQLite
Instalar sobre la fase 7.1D, conservando el resto de archivos y la base de datos.
Archivos incluidos:
- public/assistant/assistant.js (solo cambio de URL de la API)
- public/api/assistant-logic-71e.php (API nueva)
- private/assistant/dictionary.php (biblioteca y migración automática)
- tools/dictionary-admin.php (comandos SOLO CLI; NO colocar bajo public)
No reemplazar private/database/catalogo.sqlite ni CSS.

La primera consulta crea private/assistant/dictionary.sqlite; la carpeta
private/assistant debe ser escribible por PHP y estar fuera del document root.
Se recomiendan permisos restrictivos para el fichero SQLite y sus temporales.
Requiere PHP >= 8.1, PDO SQLite y mbstring.

El catálogo se consulta EN VIVO: nombres, categorías, descripción y search_text.
Los sinónimos aprobados se guardan en SQLite y sobreviven reinicios.
Las palabras desconocidas se agregan como propuestas (hasta 3 por consulta),
SIN guardar frases completas ni datos de clientes. Nunca se aprueban solas.
El administrador revisa las propuestas por SSH (CLI):
 php tools/dictionary-admin.php pending
 php tools/dictionary-admin.php approve papas patata
 php tools/dictionary-admin.php ignore palabra

Seguridad: la API pública es SOLO lectura del catálogo y no ejecuta órdenes.
Las propuestas pueden contener basura introducida por visitantes; revisar.
No almacena texto completo de las consultas. El listado de desconocidas
puede contener palabras sensibles introducidas por visitantes: revisar
y purgar periódicamente. No publicar dictionary.sqlite ni herramientas CLI.
LIMITACIONES: reglas heurísticas, sin inferencia IA ni permisos de negocio;
sin aprendizaje autónomo de asociaciones y sin datos privados.
Pruebas de sintaxis PHP y JavaScript superadas. Prueba funcional no ejecutable en este entorno (faltan extensiones PHP mbstring y pdo_sqlite). NO probado en IONOS.
PUNTO DE CONTINUACIÓN: 7.1F interpretación avanzada, 7.1G memoria,
7.1H conectores autenticados y 7.2 operaciones con confirmación.
