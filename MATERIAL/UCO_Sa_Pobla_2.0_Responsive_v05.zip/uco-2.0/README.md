# UCO Sa Pobla 2.0 — v0.5

Proyecto frontend con Web Components nativos. Abrir `public/index.html` mediante Live Server.

## Cambios v0.5
- Anclas alineadas con cabecera sticky y estado activo de menú.
- Sección **Pedidos** independiente, preparada para futuro motor de pedidos y chatbot.
- **Contacto** pasa al footer de pantalla completa, con formulario, mapa y datos oficiales.
- El formulario usa `mailto:` como solución provisional; **no envía datos al servidor**. Requiere configurar un cliente de correo. En una fase posterior se conectará a un endpoint PHP con protección anti-spam, validación, RGPD y entrega transaccional.
- Fotografías 01–30 recortadas de nuevo por el interior para evitar restos de otras celdas del mosaico. Son imágenes ilustrativas, no fotografías oficiales de productos.
- `private/` debe estar fuera de la raíz web en producción.

Teléfono, correo y dirección contrastados en la página oficial de contacto: https://ucosapobla.com/es/contacto
